"""Tests for the Stage 3 training and evaluation modules."""

from __future__ import annotations

import json

import numpy as np
import pandas as pd
import pytest
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression

from config import settings
from src.data.loader import FEATURE_COLUMNS, NUMERIC_COLUMNS, read_connections
from src.features.preprocess import build_preprocessor, build_xy, transform_frame
from src.models.evaluate import evaluate_model, format_metrics
from src.models.train import (
    CANDIDATE_NAMES,
    benign_profile,
    build_candidates,
    global_importance,
    load_bundle,
    save_bundle,
)

BUNDLE_PRESENT = (settings.ARTIFACT_DIR / "model.joblib").is_file()
METRICS_PRESENT = (settings.ARTIFACT_DIR / "metrics.json").is_file()
DEMO_PRESENT = (settings.DEMO_DIR / "demo_connections.csv").is_file()


def _raw_frame(rows: int = 60) -> pd.DataFrame:
    """Build a small but complete labelled NSL-KDD-shaped frame."""
    rng = np.random.default_rng(settings.RANDOM_STATE)
    data: dict[str, object] = {}
    for column in FEATURE_COLUMNS:
        if column == "protocol_type":
            data[column] = rng.choice(["tcp", "udp"], size=rows)
        elif column == "service":
            data[column] = rng.choice(["http", "ftp"], size=rows)
        elif column == "flag":
            data[column] = rng.choice(["SF", "REJ"], size=rows)
        else:
            data[column] = rng.integers(0, 100, size=rows)

    frame = pd.DataFrame(data)
    frame["label"] = "normal"
    frame["category"] = [
        settings.CLASS_ORDER[index % len(settings.CLASS_ORDER)]
        for index in range(rows)
    ]
    frame["is_attack"] = frame["category"] != "Normal"
    return frame


def _encoded(frame: pd.DataFrame):
    features, multi_target, _ = build_xy(frame)
    preprocessor = build_preprocessor()
    preprocessor.fit(features)
    return preprocessor, transform_frame(preprocessor, features), multi_target


def test_evaluate_model_returns_complete_report():
    frame = _raw_frame(50)
    preprocessor, matrix, target = _encoded(frame)
    estimator = DummyClassifier(strategy="most_frequent").fit(matrix, target)

    metrics = evaluate_model(
        estimator, matrix, target, labels=settings.CLASS_ORDER
    )

    assert metrics["n_samples"] == 50
    assert 0.0 <= metrics["macro_f1"] <= 1.0
    assert set(metrics["per_class"]) == set(settings.CLASS_ORDER)
    assert sum(sum(row) for row in metrics["confusion_matrix"]["matrix"]) == 50
    assert set(metrics["binary_attack"]) >= {
        "precision",
        "recall",
        "false_positive_rate",
        "roc_auc",
    }
    assert "macro-F1" in format_metrics(metrics)
    assert "attack:" in format_metrics(metrics)


def test_global_importance_random_forest_is_normalised():
    frame = _raw_frame(60)
    _, matrix, target = _encoded(frame)
    estimator = RandomForestClassifier(
        n_estimators=10, random_state=settings.RANDOM_STATE
    ).fit(matrix, target)

    importance = global_importance(estimator, list(matrix.columns))

    assert len(importance) == matrix.shape[1]
    assert sum(importance.values()) == pytest.approx(1.0)
    values = list(importance.values())
    assert values == sorted(values, reverse=True)


def test_global_importance_linear_model_uses_coefficients():
    frame = _raw_frame(60)
    _, matrix, target = _encoded(frame)
    estimator = LogisticRegression(
        max_iter=500, class_weight="balanced", random_state=settings.RANDOM_STATE
    ).fit(matrix, target)

    importance = global_importance(estimator, list(matrix.columns))

    assert len(importance) == matrix.shape[1]
    assert sum(importance.values()) == pytest.approx(1.0)


def test_global_importance_permutation_fallback():
    frame = _raw_frame(40)
    _, matrix, target = _encoded(frame)
    estimator = HistGradientBoostingClassifier(
        max_iter=5, random_state=settings.RANDOM_STATE
    ).fit(matrix, target)

    importance = global_importance(
        estimator,
        list(matrix.columns),
        x_reference=matrix,
        y_reference=target,
    )

    assert len(importance) == matrix.shape[1]
    assert sum(importance.values()) == pytest.approx(1.0)


def test_global_importance_requires_reference_for_fallback():
    frame = _raw_frame(20)
    _, matrix, target = _encoded(frame)
    estimator = HistGradientBoostingClassifier(
        max_iter=5, random_state=settings.RANDOM_STATE
    ).fit(matrix, target)

    with pytest.raises(ValueError, match="x_reference"):
        global_importance(estimator, list(matrix.columns))


def test_benign_profile_covers_all_feature_groups():
    frame = _raw_frame(60)
    profile = benign_profile(frame)

    assert profile["n_rows"] == 12  # every fifth row is Normal
    assert set(profile["numeric"]) == set(NUMERIC_COLUMNS)
    assert set(profile["categorical"]) == set(settings.CATEGORICAL_FEATURES)
    assert "mode" in profile["categorical"]["service"]
    assert 0.0 <= sum(profile["categorical"]["service"]["shares"].values()) <= 1.0


def test_benign_profile_rejects_unlabelled_frame():
    with pytest.raises(ValueError, match="label_connections"):
        benign_profile(_raw_frame(10).drop(columns=["category"]))


def test_bundle_roundtrip(tmp_path):
    frame = _raw_frame(40)
    preprocessor, matrix, target = _encoded(frame)
    estimator = DummyClassifier(strategy="prior").fit(matrix, target)
    bundle = {
        "version": "test",
        "model_name": "dummy",
        "preprocessor": preprocessor,
        "estimator": estimator,
        "classes": [str(value) for value in estimator.classes_],
        "feature_names": list(matrix.columns),
        "global_importance": {"numeric__duration": 1.0},
        "benign_profile": benign_profile(frame),
    }

    path = save_bundle(bundle, tmp_path / "model.joblib")
    restored = load_bundle(path)

    assert restored["model_name"] == "dummy"
    assert restored["classes"] == bundle["classes"]
    assert restored["feature_names"] == bundle["feature_names"]


def test_missing_bundle_has_actionable_error(tmp_path):
    with pytest.raises(FileNotFoundError, match="train_models"):
        load_bundle(tmp_path / "missing.joblib")


def test_candidate_registry_is_stable():
    candidates = build_candidates(quick=True)
    assert tuple(candidates) == CANDIDATE_NAMES
    assert candidates["random_forest"].n_estimators == 80


@pytest.mark.skipif(not BUNDLE_PRESENT, reason="model bundle not trained yet")
def test_saved_bundle_matches_contract():
    bundle = load_bundle()

    assert bundle["model_name"] in CANDIDATE_NAMES
    assert bundle["class_order"] == settings.CLASS_ORDER
    assert set(bundle["classes"]) == set(settings.CLASS_ORDER)
    assert len(bundle["feature_names"]) > len(FEATURE_COLUMNS)
    assert bundle["global_importance"]
    assert bundle["benign_profile"]["n_rows"] > 0


@pytest.mark.skipif(
    not (BUNDLE_PRESENT and DEMO_PRESENT),
    reason="model bundle or demo sample missing",
)
def test_saved_bundle_predicts_demo_sample():
    bundle = load_bundle()
    demo = read_connections(settings.DEMO_DIR / "demo_connections.csv")
    matrix = transform_frame(bundle["preprocessor"], demo[FEATURE_COLUMNS])

    probabilities = bundle["estimator"].predict_proba(matrix)
    predictions = bundle["estimator"].predict(matrix)

    assert probabilities.shape[0] == len(demo)
    assert np.allclose(probabilities.sum(axis=1), 1.0)
    assert set(str(value) for value in predictions) <= set(settings.CLASS_ORDER)


@pytest.mark.skipif(not METRICS_PRESENT, reason="metrics not trained yet")
def test_saved_metrics_match_contract():
    payload = json.loads(
        (settings.ARTIFACT_DIR / "metrics.json").read_text(encoding="utf-8")
    )

    assert payload["selected_model"] in CANDIDATE_NAMES
    assert payload["selection_metric"] == settings.PRIMARY_METRIC
    assert payload["test"]["n_samples"] == settings.DATASET_EXPECTED_ROWS["test"]
    assert set(payload["test"]["metrics"]["per_class"]) == set(
        settings.CLASS_ORDER
    )
    assert 0.0 <= payload["test"]["metrics"]["macro_f1"] <= 1.0
