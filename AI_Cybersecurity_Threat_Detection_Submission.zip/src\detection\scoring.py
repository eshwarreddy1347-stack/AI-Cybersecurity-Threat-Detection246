"""Transparent risk scoring for threat detection.

Formula (from config.settings):
    risk = RISK_CONFIDENCE_WEIGHT * (100 * confidence) 
         + (1 - RISK_CONFIDENCE_WEIGHT) * severity_weight
         + capped modifiers

- Normal predictions get 0 risk (or very low).
- Severity bands: Critical >= 85, High >= 70, Medium >= 40, Low < 40
- All weights come from config for auditability.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import settings


def compute_risk_score(
    predicted_class: str,
    confidence: float,
    features: dict[str, Any] | pd.Series | None = None,
) -> dict[str, Any]:
    """Compute transparent risk score and severity.
    
    Returns dict with risk_score (int 0-100), severity (Low/Medium/High/Critical),
    components breakdown for transparency.
    """
    if predicted_class == "Normal":
        return {
            "risk_score": 0,
            "severity": "Low",
            "base_score": 0.0,
            "modifiers": 0,
            "components": {
                "confidence_contribution": 0.0,
                "severity_contribution": 0.0,
                "modifiers": 0,
            },
        }
    
    conf = float(max(0.0, min(1.0, confidence)))
    severity_weight = float(settings.SEVERITY_WEIGHTS.get(predicted_class, 0))
    
    confidence_contribution = settings.RISK_CONFIDENCE_WEIGHT * (100.0 * conf)
    severity_contribution = (1.0 - settings.RISK_CONFIDENCE_WEIGHT) * severity_weight
    base_score = confidence_contribution + severity_contribution
    
    modifiers = 0
    if features is not None:
        try:
            feat_dict = features.to_dict() if hasattr(features, "to_dict") else dict(features)
        except Exception:
            feat_dict = {}
        
        # Check for red flags
        if feat_dict.get("src_bytes", 0) > 0 and feat_dict.get("dst_bytes", 0) == 0:
            modifiers += settings.RISK_MODIFIERS.get("zero_byte_reply", 5)
        if int(feat_dict.get("count", 0)) > 100:
            modifiers += settings.RISK_MODIFIERS.get("burst_traffic", 5)
        flag = str(feat_dict.get("flag", "")).upper()
        if flag in {"S0", "REJ", "RSTO"}:
            modifiers += settings.RISK_MODIFIERS.get("rejected_connection", 5)
        if int(feat_dict.get("num_failed_logins", 0)) > 0:
            modifiers += settings.RISK_MODIFIERS.get("failed_logins", 5)
        if int(feat_dict.get("root_shell", 0)) == 1:
            modifiers += settings.RISK_MODIFIERS.get("root_shell", 5)
    
    modifiers = min(modifiers, settings.RISK_MODIFIER_CAP)
    risk_score = int(round(base_score + modifiers))
    risk_score = max(0, min(100, risk_score))
    
    # Assign severity
    severity = "Low"
    for threshold, band in settings.SEVERITY_BANDS:
        if risk_score >= threshold:
            severity = band
            break
    
    return {
        "risk_score": risk_score,
        "severity": severity,
        "base_score": round(base_score, 2),
        "modifiers": modifiers,
        "components": {
            "confidence_contribution": round(confidence_contribution, 2),
            "severity_contribution": round(severity_contribution, 2),
            "modifiers": modifiers,
        },
    }


def should_generate_alert(predicted_class: str, risk_score: int) -> bool:
    """Determine if an alert should be generated based on config thresholds."""
    if predicted_class == "Normal":
        return False
    return risk_score >= settings.RISK_ALERT_THRESHOLD
