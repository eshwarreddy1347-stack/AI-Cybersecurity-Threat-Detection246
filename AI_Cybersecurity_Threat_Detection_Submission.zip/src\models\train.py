"""Train, compare and persist the NSL-KDD threat classifier.

Pipeline
--------
1. Load the official train/test splits through the validated loader.
2. Reuse the **already fitted** preprocessor from ``artifacts/preprocessor.joblib``
   (never refit on test data).
3. Carve a stratified validation split out of the training data for model
   selection. The official test split is touched once, for the final report.
4. Compare three candidates, pick the best by macro-F1 (tie-break: attack
   recall), refit the winner on the full training split.
5. Save a single inference bundle plus JSON/CSV reports.

The bundle also contains a benign baseline profile and global feature
importance. Stage 4 uses them to explain *why* a connection was flagged, so the
dashboard never has to reload the 126k-row training set.
"""

from __future__ import annotations

import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import settings  # noqa: E402
from src.data.loader import NUMERIC_COLUMNS, load_dataset  # noqa: E402
from src.features.preprocess import (  # noqa: E402
    build_xy,
    load_preprocessor,
    transform_frame,
)
from src.models.evaluate import evaluate_model, format_metrics  # noqa: E402

BUNDLE_FILENAME = "model.joblib"
METRICS_FILENAME = "metrics.json"
IMPORTANCE_FILENAME = "feature_importance.csv"
CONFUSION_FILENAME = "confusion_matrix.json"
BUNDLE_VERSION = "1.0.0"

CANDIDATE_NAMES: tuple[str, ...] = (
    "logistic_regression",
    "random_forest",
    "hist_gradient_boosting",
)


def build_candidates(
    *,
    quick: bool = False,
    dev: bool = False,
    rf_trees: int | None = None,
    lr_max_iter: int | None = None,
    hgb_max_iter: int | None = None,
) -> dict[str, Any]:
    """Return fresh, unfitted candidate estimators.

    ``quick=True`` shrinks the ensembles so a smoke run finishes in a minute;
    it is for development only, not for the final reported numbers.
    """
    if dev:
        forest_trees = rf_trees if rf_trees is not None else 50
        boosting_iterations = hgb_max_iter if hgb_max_iter is not None else 100
        lr_iters = lr_max_iter if lr_max_iter is not None else 500
    else:
        forest_trees = rf_trees if rf_trees is not None else (80 if quick else 250)
        boosting_iterations = hgb_max_iter if hgb_max_iter is not None else (
            150 if quick else 350
        )
        lr_iters = lr_max_iter if lr_max_iter is not None else 2000

    return {
        "logistic_regression": LogisticRegression(
            C=1.0,
            class_weight="balanced",
            max_iter=lr_iters,
            solver="lbfgs",
            n_jobs=-1,
            random_state=settings.RANDOM_STATE,
        ),
        "random_forest": RandomForestClassifier(
            n_estimators=forest_trees,
            class_weight="balanced_subsample",
            n_jobs=-1,
            random_state=settings.RANDOM_STATE,
        ),
        "hist_gradient_boosting": HistGradientBoostingClassifier(
            max_iter=boosting_iterations,
            learning_rate=0.1,
            class_weight="balanced",
            early_stopping=True,
            validation_fraction=0.1,
            n_iter_no_change=20,
            random_state=settings.RANDOM_STATE,
        ),
    }


def global_importance(
    estimator: Any,
    feature_names: list[str],
    *,
    x_reference: Any | None = None,
    y_reference: Any | None = None,
) -> dict[str, float]:
    """Return a normalised, descending feature-importance mapping.

    Tree ensembles expose ``feature_importances_`` and linear models expose
    ``coef_``. Models without either (e.g. HistGradientBoosting) fall back to
    permutation importance on a capped sample of the validation split.
    """
    values: np.ndarray

    if hasattr(estimator, "feature_importances_"):
        values = np.asarray(estimator.feature_importances_, dtype=float)
    elif hasattr(estimator, "coef_"):
        coefficients = np.asarray(estimator.coef_, dtype=float)
        values = (
            np.abs(coefficients)
            if coefficients.ndim == 1
            else np.abs(coefficients).max(axis=0)
        )
    else:
        if x_reference is None or y_reference is None:
            raise ValueError(
                "estimator has no native importance; pass x_reference/y_reference"
            )
        if hasattr(x_reference, "iloc"):
            sample_size = min(len(x_reference), 2500)
            rng = np.random.default_rng(settings.RANDOM_STATE)
            indices = rng.choice(len(x_reference), size=sample_size, replace=False)
            x_sample = x_reference.iloc[indices]
            y_sample = np.asarray(y_reference)[indices]
        else:
            sample_size = min(len(x_reference), 2500)
            rng = np.random.default_rng(settings.RANDOM_STATE)
            indices = rng.choice(len(x_reference), size=sample_size, replace=False)
            x_sample = np.asarray(x_reference)[indices]
            y_sample = np.asarray(y_reference)[indices]

        result = permutation_importance(
            estimator,
            x_sample,
            y_sample,
            n_repeats=3,
            random_state=settings.RANDOM_STATE,
            scoring="f1_macro",
            n_jobs=-1,
        )
        values = np.clip(np.asarray(result.importances_mean, dtype=float), 0.0, None)

    if len(values) != len(feature_names):
        raise ValueError(
            f"importance length {len(values)} does not match "
            f"{len(feature_names)} feature names"
        )

    total = float(values.sum())
    if total > 0:
        values = values / total

    ranked = sorted(
        zip(feature_names, values.tolist(), strict=True),
        key=lambda pair: pair[1],
        reverse=True,
    )
    return {name: float(value) for name, value in ranked}


def benign_profile(frame: pd.DataFrame) -> dict[str, Any]:
    """Summarise benign training connections for later evidence scoring.

    Stage 4 compares an alert's raw feature values against this baseline. The
    profile is precomputed so the dashboard does not load 126k rows at runtime.
    """
    if "category" not in frame.columns:
        raise ValueError("frame must be labelled with label_connections() first")

    normal = frame[frame["category"] == "Normal"]
    if normal.empty:
        raise ValueError("no benign rows found; cannot build a baseline profile")

    numeric: dict[str, dict[str, float]] = {}
    for column in NUMERIC_COLUMNS:
        series = pd.to_numeric(normal[column], errors="coerce").dropna()
        numeric[column] = {
            "mean": float(series.mean()),
            "std": float(series.std(ddof=0)),
            "median": float(series.median()),
            "q1": float(series.quantile(0.25)),
            "q3": float(series.quantile(0.75)),
            "min": float(series.min()),
            "max": float(series.max()),
        }

    categorical: dict[str, dict[str, Any]] = {}
    for column in settings.CATEGORICAL_FEATURES:
        shares = normal[column].astype(str).value_counts(normalize=True)
        categorical[column] = {
            "mode": str(shares.index[0]),
            "shares": {
                str(value): round(float(share), 6)
                for value, share in shares.items()
            },
        }

    return {
        "n_rows": int(len(normal)),
        "numeric": numeric,
        "categorical": categorical,
    }


def save_bundle(bundle: dict[str, Any], path: Path | None = None) -> Path:
    """Persist the inference bundle with compression."""
    destination = path or (settings.ARTIFACT_DIR / BUNDLE_FILENAME)
    destination.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, destination, compress=3)
    return destination


def load_bundle(path: Path | None = None) -> dict[str, Any]:
    """Load the bundle written by ``scripts/train_models.py``."""
    if path is None:
        source = settings.ARTIFACT_DIR / BUNDLE_FILENAME
    else:
        source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(
            f"model bundle not found: {source}. "
            "Run: python scripts\\train_models.py"
        )

    bundle = joblib.load(source)
    required = {"preprocessor", "estimator", "classes", "feature_names"}
    missing = required - set(bundle)
    if missing:
        raise ValueError(
            f"model bundle is incomplete; missing keys: {sorted(missing)}"
        )
    return bundle


def _select_best(results: dict[str, dict[str, Any]]) -> str:
    """Pick the candidate with the best macro-F1, then attack recall."""
    best_name: str | None = None
    for name in CANDIDATE_NAMES:
        if name not in results:
            continue
        if best_name is None:
            best_name = name
            continue

        candidate = results[name]["validation"]
        incumbent = results[best_name]["validation"]
        candidate_key = (
            candidate["macro_f1"],
            candidate["binary_attack"]["recall"],
        )
        incumbent_key = (
            incumbent["macro_f1"],
            incumbent["binary_attack"]["recall"],
        )
        if candidate_key > incumbent_key:
            best_name = name
    assert best_name is not None
    return best_name


def train_all(
    *,
    model_names: list[str] | None = None,
    quick: bool = False,
    dev: bool = False,
    dev_sample_frac: float = 0.2,
    rf_trees: int | None = None,
    lr_max_iter: int | None = None,
    hgb_max_iter: int | None = None,
    output_dir: Path | None = None,
    verbose: bool = True,
) -> dict[str, Any]:
    """Run the full training workflow and write every artifact."""
    settings.ensure_directories()
    destination = Path(output_dir) if output_dir else settings.ARTIFACT_DIR
    destination.mkdir(parents=True, exist_ok=True)

    dataset = load_dataset()
    train_frame, test_frame = dataset["train"], dataset["test"]
    preprocessor = load_preprocessor()

    x_train_raw, y_train, _ = build_xy(train_frame)
    x_test_raw, y_test, _ = build_xy(test_frame)
    x_train = transform_frame(preprocessor, x_train_raw)
    x_test = transform_frame(preprocessor, x_test_raw)
    feature_names = list(x_train.columns)

    x_fit_full, x_val, y_fit_full, y_val = train_test_split(
        x_train,
        y_train,
        test_size=settings.TEST_SIZE,
        stratify=y_train,
        random_state=settings.RANDOM_STATE,
    )

    sample_based = False
    if dev and dev_sample_frac < 1.0:
        if dev_sample_frac <= 0:
            raise ValueError("dev_sample_frac must be > 0")
        x_fit, x_fit_discard, y_fit, y_fit_discard = train_test_split(
            x_fit_full,
            y_fit_full,
            train_size=dev_sample_frac,
            stratify=y_fit_full,
            random_state=settings.RANDOM_STATE,
        )
        del x_fit_discard, y_fit_discard
        sample_based = True
    else:
        x_fit, y_fit = x_fit_full, y_fit_full

    candidates = build_candidates(
        quick=quick,
        dev=dev,
        rf_trees=rf_trees,
        lr_max_iter=lr_max_iter,
        hgb_max_iter=hgb_max_iter,
    )
    if model_names:
        requested = set(model_names)
        unknown = sorted(requested - set(candidates))
        if unknown:
            raise ValueError(
                f"unknown model(s): {unknown}; choose from {list(candidates)}"
            )
        candidates = {
            name: candidates[name]
            for name in CANDIDATE_NAMES
            if name in requested
        }

    if verbose:
        print(
            f"Training on {len(x_fit):,} rows"
            + (f" (stratified {dev_sample_frac:.0%} dev sample)" if sample_based else "")
            + f", validating on {len(x_val):,} "
            f"({len(feature_names)} encoded features)"
        )
        if sample_based:
            print("NOTE: Development/sample-based training - official test split remains untouched and will be evaluated if not in dev-only mode.")
        print()

    results: dict[str, dict[str, Any]] = {}
    for name, estimator in candidates.items():
        started = time.perf_counter()
        fitted = estimator.fit(x_fit, y_fit)
        fit_seconds = time.perf_counter() - started
        validation = evaluate_model(
            fitted, x_val, y_val, labels=settings.CLASS_ORDER
        )
        results[name] = {
            "estimator": fitted,
            "validation": validation,
            "fit_seconds": fit_seconds,
        }
        if verbose:
            print(
                format_metrics(
                    validation,
                    title=f"{name} (validation)",
                    detailed=False,
                )
            )
            print(f"  fit time: {fit_seconds:.1f}s\n")

    best_name = _select_best(results)
    if verbose:
        print(f"Selected model: {best_name}")

    started = time.perf_counter()
    if sample_based:
        if verbose:
            print(
                "\n[DEV MODE] Skipping final refit on full training set and official test evaluation (test set untouched)."
            )
        final_estimator = None
        final_seconds = 0.0
        test_metrics = None
        importance = global_importance(
            results[best_name]["estimator"],
            feature_names,
            x_reference=x_val,
            y_reference=y_val,
        )
        profile = benign_profile(train_frame)
    else:
        final_estimator = clone(results[best_name]["estimator"]).fit(x_train, y_train)
        final_seconds = time.perf_counter() - started

        test_metrics = evaluate_model(
            final_estimator, x_test, y_test, labels=settings.CLASS_ORDER
        )
        if verbose:
            print()
            print(format_metrics(test_metrics, title="Final model (official test split)"))
            print(f"  fit time: {final_seconds:.1f}s\n")

        importance = global_importance(
            final_estimator,
            feature_names,
            x_reference=x_val,
            y_reference=y_val,
        )
        profile = benign_profile(train_frame)

    trained_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    bundle: dict[str, Any] | None = None
    if not sample_based and final_estimator is not None:
        bundle = {
            "version": BUNDLE_VERSION,
            "trained_at": trained_at,
            "dataset": settings.DATASET_NAME,
            "model_name": best_name,
            "estimator": final_estimator,
            "preprocessor": preprocessor,
            "classes": [str(value) for value in final_estimator.classes_],
            "class_order": list(settings.CLASS_ORDER),
            "feature_names": feature_names,
            "global_importance": importance,
            "benign_profile": profile,
            "training": {
                "n_train": int(len(x_train)),
                "n_validation": int(len(x_val)),
                "quick_mode": bool(quick),
                "dev_mode": bool(dev),
                "sample_based": bool(sample_based),
                "selection_metric": settings.PRIMARY_METRIC,
            },
        }
        bundle_path = save_bundle(bundle, destination / BUNDLE_FILENAME)
    else:
        bundle_path = None

    payload: dict[str, Any] = {
        "version": BUNDLE_VERSION,
        "generated_at": trained_at,
        "dataset": settings.DATASET_NAME,
        "selected_model": best_name,
        "selection_metric": settings.PRIMARY_METRIC,
        "mode": "dev_sample" if sample_based else ("dev" if dev else "full"),
        "sample_based": sample_based,
        "training": {
            "n_train_full": int(len(x_train)),
            "n_train_used": int(len(x_fit)),
            "n_validation": int(len(x_val)),
            "validation_fraction": settings.TEST_SIZE,
            "dev_sample_frac": float(dev_sample_frac) if sample_based else 1.0,
            "quick_mode": bool(quick),
            "dev_mode": bool(dev),
            "candidate_names": list(results),
        },
        "candidates": {
            name: {
                "validation": result["validation"],
                "fit_seconds": round(result["fit_seconds"], 2),
            }
            for name, result in results.items()
        },
    }
    if test_metrics is not None and final_estimator is not None:
        payload["test"] = {
            "n_samples": int(len(x_test)),
            "metrics": test_metrics,
            "fit_seconds": round(final_seconds, 2),
            "untouched": True,
        }
    else:
        payload["test"] = {
            "untouched": True,
            "note": "Not evaluated in dev/sample mode; official test set not used.",
        }

    metrics_path = destination / METRICS_FILENAME
    metrics_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    importance_path = destination / IMPORTANCE_FILENAME
    pd.DataFrame(
        {
            "feature": list(importance),
            "importance": list(importance.values()),
        }
    ).to_csv(importance_path, index=False)

    if test_metrics is not None:
        confusion_path = destination / CONFUSION_FILENAME
        confusion_path.write_text(
            json.dumps(
                {
                    "model": best_name,
                    "split": "official test",
                    **test_metrics["confusion_matrix"],
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        payload["artifacts"] = {
            "bundle": str(bundle_path) if bundle_path else None,
            "metrics": str(metrics_path),
            "feature_importance": str(importance_path),
            "confusion_matrix": str(confusion_path),
        }
    else:
        payload["artifacts"] = {
            "bundle": None,
            "metrics": str(metrics_path),
            "feature_importance": str(importance_path),
            "confusion_matrix": None,
        }
    metrics_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    if verbose:
        if bundle_path:
            print(f"Saved model bundle  -> {bundle_path}")
        else:
            print("Saved model bundle  -> [SKIPPED - dev/sample mode]")
        print(f"Saved metrics       -> {metrics_path}")
        print(f"Saved importance    -> {importance_path}")
        if test_metrics is not None:
            print(f"Saved confusion     -> {confusion_path}")
        else:
            print("Saved confusion     -> [SKIPPED - official test untouched]")

    return payload
