"""Alert Details - Deep dive into individual alerts"""

import streamlit as st
import pandas as pd
import json
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from config import settings
from src.alerts.db import AlertDB

st.set_page_config(page_title="Alert Details", page_icon="🔍", layout="wide")

st.title("🔍 Alert Details")
st.caption("Deep dive into alert evidence and supporting information")

db = AlertDB()
alerts = db.get_all_alerts(limit=10000)

if not alerts:
    st.warning("No alerts in database")
    st.stop()

df = pd.DataFrame(alerts)

selected_alert = st.selectbox("Select Alert to Inspect", 
                              options=df['alert_id'].tolist(),
                              format_func=lambda x: f"{x[:12]}... | {df[df['alert_id']==x]['predicted_class'].values[0]} | Risk: {df[df['alert_id']==x]['risk_score'].values[0]} | {df[df['alert_id']==x]['severity'].values[0]}")

alert_row = df[df['alert_id'] == selected_alert].iloc[0]

# Header
col1, col2, col3, col4 = st.columns(4)
col1.metric("Alert ID", selected_alert[:12] + "...")
col2.metric("Severity", alert_row['severity'])
col3.metric("Risk Score", alert_row['risk_score'])
col4.metric("Status", alert_row['status'])

st.divider()

# Basic Info
st.subheader("Basic Information")
c1, c2, c3 = st.columns(3)
with c1:
    st.text_input("Predicted Class", value=alert_row['predicted_class'], disabled=True)
    st.text_input("Confidence", value=f"{alert_row['confidence']:.6f}", disabled=True)
    st.text_input("Attack Probability", value=f"{alert_row['attack_probability']:.6f}", disabled=True)
with c2:
    st.text_input("Asset (Simulated)", value=alert_row['asset'] or "N/A", disabled=True)
    st.text_input("Sensor ID", value=alert_row['sensor_id'] or "N/A", disabled=True)
    st.text_input("Model", value=alert_row['model_name'] or "N/A", disabled=True)
with c3:
    st.text_input("Created At", value=str(alert_row['created_at']), disabled=True)
    st.text_input("Updated At", value=str(alert_row['updated_at']), disabled=True)
    st.text_input("Occurrence Count", value=str(alert_row['occurrence_count']), disabled=True)

st.warning("⚠️ **Note:** Asset information is simulated presentation metadata. NSL-KDD dataset does not contain IP addresses.")

st.divider()

# Evidence
st.subheader("Supporting Evidence")
if alert_row['evidence']:
    try:
        evidence = json.loads(alert_row['evidence'])
        
        tab1, tab2, tab3, tab4 = st.tabs(["Red Flags", "Top Features", "Dataset Evidence", "Simulated Info"])
        
        with tab1:
            st.markdown("**Rule-based Red Flags:**")
            if evidence.get('red_flags'):
                for flag in evidence['red_flags']:
                    st.warning(f"🚩 {flag}")
            else:
                st.info("No specific red flags detected")
        
        with tab2:
            st.markdown("**Top Contributing Features (by importance):**")
            if evidence.get('top_features'):
                feat_df = pd.DataFrame(evidence['top_features'])
                st.dataframe(feat_df, use_container_width=True, hide_index=True)
            else:
                st.info("No feature importance data available")
        
        with tab3:
            st.markdown("**Actual NSL-KDD Dataset Evidence:**")
            st.caption("*These are real features from the dataset*")
            if evidence.get('dataset_evidence'):
                de = evidence['dataset_evidence']
                c1, c2 = st.columns(2)
                with c1:
                    st.text_input("Protocol Type", value=de.get('protocol_type'), disabled=True)
                    st.text_input("Service", value=de.get('service'), disabled=True)
                    st.text_input("Flag", value=de.get('flag'), disabled=True)
                with c2:
                    st.text_input("Source Bytes", value=de.get('src_bytes'), disabled=True)
                    st.text_input("Destination Bytes", value=de.get('dst_bytes'), disabled=True)
                    st.text_input("Connection Count", value=de.get('count'), disabled=True)
                st.info(de.get('note', ''))
        
        with tab4:
            st.markdown("**Simulated Presentation Metadata:**")
            st.caption("*Clearly labeled as simulated*")
            if evidence.get('simulated_info'):
                si = evidence['simulated_info']
                st.text_input("Mapped Asset", value=si.get('asset'), disabled=True)
                st.text_input("Sensor ID", value=si.get('sensor_id'), disabled=True)
                st.warning(si.get('note', ''))
        
    except Exception as e:
        st.error(f"Error parsing evidence: {e}")
        st.code(alert_row['evidence'])

st.divider()

# Risk Components
st.subheader("Risk Score Breakdown")
if alert_row['risk_components']:
    try:
        rc = json.loads(alert_row['risk_components'])
        c1, c2, c3 = st.columns(3)
        c1.metric("Confidence Contribution", f"{rc.get('confidence_contribution', 0):.2f}")
        c2.metric("Severity Contribution", f"{rc.get('severity_contribution', 0):.2f}")
        c3.metric("Modifiers", f"{rc.get('modifiers', 0)}")
        st.caption("Formula: 0.4 × (100 × confidence) + 0.6 × severity_weight + capped modifiers")
    except:
        pass

st.divider()

# Audit Trail
st.subheader("Audit Trail")
conn = db.get_connection()
events = conn.execute("SELECT * FROM alert_events WHERE alert_id = ? ORDER BY timestamp", (selected_alert,)).fetchall()
conn.close()

if events:
    events_df = pd.DataFrame([dict(e) for e in events])
    st.dataframe(events_df, use_container_width=True, hide_index=True)
else:
    st.info("No audit events recorded yet")
