"""Generate supporting evidence for alerts.

Evidence combines:
1. Model confidence and top contributing features
2. Rule-based red flags from config
3. Clear labeling of simulated vs actual dataset evidence
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import settings


def generate_evidence(
    predicted_class: str,
    confidence: float,
    features: dict[str, Any] | pd.Series,
    global_importance: dict[str, float] | None = None,
    top_k: int = 5,
) -> dict[str, Any]:
    """Generate human-readable evidence for an alert."""
    try:
        feat_dict = features.to_dict() if hasattr(features, "to_dict") else dict(features)
    except Exception:
        feat_dict = {}
    
    evidence = {
        "model_confidence": round(float(confidence), 4),
        "predicted_class": predicted_class,
        "red_flags": [],
        "top_features": [],
        "dataset_evidence": {},
        "simulated_info": {
            "note": "Asset information is simulated presentation metadata (NSL-KDD has no IP addresses)",
            "asset": settings.asset_for_service(feat_dict.get("service", "unknown")),
            "sensor_id": settings.SENSOR_ID,
        },
    }
    
    # Rule-based red flags
    if feat_dict.get("src_bytes", 0) > 0 and feat_dict.get("dst_bytes", 0) == 0:
        evidence["red_flags"].append("Zero-byte reply (sent data, received nothing)")
    if int(feat_dict.get("count", 0)) > 100:
        evidence["red_flags"].append(f"High connection count: {feat_dict.get('count')}")
    flag = str(feat_dict.get("flag", ""))
    if flag.upper() in {"S0", "REJ", "RSTO"}:
        evidence["red_flags"].append(f"Suspicious connection flag: {flag}")
    if int(feat_dict.get("num_failed_logins", 0)) > 0:
        evidence["red_flags"].append(f"Failed login attempts: {feat_dict.get('num_failed_logins')}")
    if int(feat_dict.get("root_shell", 0)) == 1:
        evidence["red_flags"].append("Root shell obtained")
    
    # Top contributing features (from global importance)
    if global_importance and feat_dict:
        sorted_features = sorted(
            global_importance.items(), key=lambda x: x[1], reverse=True
        )[:top_k]
        for feat_name, imp in sorted_features:
            # Map back to original feature if possible
            orig_name = feat_name
            if feat_name.startswith("numeric__"):
                orig_name = feat_name.replace("numeric__", "")
            elif feat_name.startswith("categorical__"):
                # Extract original name
                for cat in settings.CATEGORICAL_FEATURES:
                    if f"categorical__{cat}_" in feat_name:
                        orig_name = f"{cat}={feat_name.split('_')[-1]}"
                        break
            
            evidence["top_features"].append({
                "feature": orig_name,
                "importance": round(float(imp), 6),
                "value": feat_dict.get(orig_name.split("=")[0] if "=" in orig_name else orig_name),
            })
    
    # Key dataset evidence
    evidence["dataset_evidence"] = {
        "protocol_type": feat_dict.get("protocol_type"),
        "service": feat_dict.get("service"),
        "flag": feat_dict.get("flag"),
        "src_bytes": feat_dict.get("src_bytes"),
        "dst_bytes": feat_dict.get("dst_bytes"),
        "count": feat_dict.get("count"),
        "note": "Actual NSL-KDD dataset features (no IP addresses present)",
    }
    
    return evidence
