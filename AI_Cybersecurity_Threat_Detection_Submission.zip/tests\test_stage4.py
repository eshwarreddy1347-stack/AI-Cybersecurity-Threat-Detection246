"""Tests for Stage 4: Risk scoring and alert generation."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from config import settings
from src.detection.scoring import compute_risk_score, should_generate_alert
from src.detection.evidence import generate_evidence
from src.alerts.db import AlertDB
from src.data.loader import FEATURE_COLUMNS


def test_normal_traffic_zero_risk():
    """Normal predictions must receive zero or very low risk."""
    result = compute_risk_score("Normal", 0.9999)
    assert result["risk_score"] == 0
    assert result["severity"] == "Low"
    assert should_generate_alert("Normal", 0) is False


def test_risk_calculation_transparent():
    """Risk calculation uses the formula from config."""
    features = {"src_bytes": 0, "dst_bytes": 1000, "count": 10, "flag": "SF"}
    result = compute_risk_score("DoS", 0.95, features)
    assert result["risk_score"] > 0
    assert result["severity"] in ["Low", "Medium", "High", "Critical"]
    assert "components" in result
    assert result["components"]["confidence_contribution"] > 0
    assert result["components"]["severity_contribution"] > 0


def test_severity_levels():
    """Test all four severity levels."""
    # Critical >= 85
    result_crit = compute_risk_score("U2R", 1.0, {"src_bytes": 0, "dst_bytes": 0, "count": 1, "flag": "SF"})
    assert result_crit["risk_score"] >= 85
    assert result_crit["severity"] == "Critical"
    
    # High >= 70
    result_high = compute_risk_score("R2L", 0.85)
    assert result_high["risk_score"] >= 70
    assert result_high["severity"] in ["High", "Critical"]
    
    # Medium >= 40
    result_med = compute_risk_score("DoS", 0.5)
    assert result_med["risk_score"] >= 40
    
    # Low < 40
    result_low = compute_risk_score("Probe", 0.3)
    assert result_low["severity"] in ["Low", "Medium"]


def test_risk_modifiers_capped():
    """Risk modifiers should be capped."""
    features = {
        "src_bytes": 100, "dst_bytes": 0,  # zero byte reply
        "count": 200,  # burst traffic
        "flag": "S0",  # rejected
        "num_failed_logins": 3,
        "root_shell": 1,
    }
    result = compute_risk_score("U2R", 0.99, features)
    assert result["modifiers"] <= settings.RISK_MODIFIER_CAP


def test_evidence_generation():
    """Evidence should be generated with required fields."""
    features = {"protocol_type": "tcp", "service": "http", "flag": "SF", 
                "src_bytes": 100, "dst_bytes": 200, "count": 1}
    evidence = generate_evidence("DoS", 0.95, features)
    
    assert evidence["predicted_class"] == "DoS"
    assert evidence["model_confidence"] == 0.95
    assert "red_flags" in evidence
    assert "top_features" in evidence
    assert "dataset_evidence" in evidence
    assert "simulated_info" in evidence
    assert "simulated" in evidence["simulated_info"]["note"].lower()
    assert evidence["simulated_info"]["asset"]  # should have simulated asset
    assert evidence["dataset_evidence"]["note"].lower().find("actual") >= 0


def test_evidence_distinguishes_simulated_from_actual():
    """Simulated asset info must be clearly distinguished from actual dataset evidence."""
    features = {"protocol_type": "tcp", "service": "http", "flag": "REJ", 
                "src_bytes": 0, "dst_bytes": 0}
    evidence = generate_evidence("Probe", 0.8, features)
    
    # Simulated section should say so
    assert "simulated" in evidence["simulated_info"]["note"].lower()
    # Dataset evidence should say it's actual NSL-KDD features
    assert "actual" in evidence["dataset_evidence"]["note"].lower()
    assert "ip addresses" in evidence["dataset_evidence"]["note"].lower()


def test_alert_storage_sqlite(tmp_path):
    """Alerts should be stored in SQLite."""
    db_path = tmp_path / "test_alerts.db"
    db = AlertDB(db_path)
    
    alert = {
        "alert_id": "test-123",
        "timestamp": "2026-01-01T00:00:00+00:00",
        "predicted_class": "DoS",
        "confidence": 0.95,
        "attack_probability": 0.98,
        "risk_score": 75,
        "severity": "High",
        "status": "New",
        "asset": "web-01",
        "sensor_id": "sensor-demo-01",
        "evidence": json.dumps({"test": "data"}),
        "raw_features": json.dumps({}),
        "risk_components": json.dumps({}),
        "model_name": "hist_gradient_boosting",
    }
    
    alert_id = db.insert_alert(alert)
    assert alert_id == "test-123"
    assert db.get_alert_count() == 1
    
    alerts = db.get_all_alerts()
    assert len(alerts) == 1
    assert alerts[0]["predicted_class"] == "DoS"
    assert alerts[0]["risk_score"] == 75
    assert alerts[0]["severity"] == "High"


def test_alert_has_required_fields(tmp_path):
    """Alert must contain timestamp, predicted class, confidence, risk score, severity, evidence."""
    from src.detection.detector import ThreatDetector
    from src.data.loader import load_split
    
    det = ThreatDetector("artifacts/stage3_final/model_hgb_full.joblib")
    test = load_split("test").head(5)
    alerts = det.generate_alerts(test, generate_all_attacks=True)
    
    assert len(alerts) > 0
    for alert in alerts:
        assert "alert_id" in alert
        assert "timestamp" in alert
        assert "predicted_class" in alert
        assert "confidence" in alert
        assert "risk_score" in alert
        assert "severity" in alert
        assert "evidence" in alert
        assert alert["severity"] in ["Low", "Medium", "High", "Critical"]
        # Normal should have zero risk
        if alert["predicted_class"] == "Normal":
            assert alert["risk_score"] == 0


def test_no_live_traffic_no_blocking():
    """Ensure no live traffic capture or blocking code."""
    # Just verify imports work and no network capture
    from src.detection import detector, scoring, evidence
    from src.alerts import db
    assert True
