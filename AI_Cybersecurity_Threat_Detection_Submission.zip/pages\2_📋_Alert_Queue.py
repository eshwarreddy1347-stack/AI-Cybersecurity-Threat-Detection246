"""Alert Queue - Manage security alerts"""

import streamlit as st
import pandas as pd
import json
from pathlib import Path
import sys
from datetime import datetime, timezone

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from config import settings
from src.alerts.db import AlertDB

st.set_page_config(page_title="Alert Queue", page_icon="📋", layout="wide")

st.title("📋 Alert Queue")
st.caption("Manage and track security alerts")

db = AlertDB()
alerts = db.get_all_alerts(limit=10000)

if not alerts:
    st.warning("No alerts in database")
    st.stop()

df = pd.DataFrame(alerts)

# Filters
st.subheader("Filters")
col1, col2, col3, col4 = st.columns(4)

with col1:
    status_filter = st.multiselect("Status", options=sorted(df['status'].unique()), default=sorted(df['status'].unique()))
with col2:
    severity_filter = st.multiselect("Severity", options=['Critical', 'High', 'Medium', 'Low'], default=['Critical', 'High', 'Medium', 'Low'])
with col3:
    class_filter = st.multiselect("Attack Class", options=sorted(df['predicted_class'].unique()), default=sorted(df['predicted_class'].unique()))
with col4:
    asset_filter = st.multiselect("Asset (Simulated)", options=sorted(df['asset'].fillna('Unknown').unique()), default=sorted(df['asset'].fillna('Unknown').unique()))

# Apply filters
filtered_df = df[
    (df['status'].isin(status_filter)) &
    (df['severity'].isin(severity_filter)) &
    (df['predicted_class'].isin(class_filter)) &
    (df['asset'].fillna('Unknown').isin(asset_filter))
].copy()

st.info(f"Showing {len(filtered_df)} of {len(df)} alerts")

# CSV Export
csv = filtered_df.to_csv(index=False)
st.download_button(
    label="📥 Export to CSV",
    data=csv,
    file_name=f"alerts_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
    mime="text/csv"
)

st.divider()

# Alert Table
st.subheader("Alert List")
display_df = filtered_df[[
    'alert_id', 'created_at', 'predicted_class', 'confidence', 
    'risk_score', 'severity', 'status', 'asset', 'sensor_id'
]].copy()
display_df['confidence'] = display_df['confidence'].apply(lambda x: f"{x:.4f}")
display_df['created_at'] = pd.to_datetime(display_df['created_at']).dt.strftime('%Y-%m-%d %H:%M:%S')

st.dataframe(display_df, use_container_width=True, hide_index=True, height=400)

st.divider()

# Alert Management
st.subheader("Alert Management")
st.caption("⚠️ Asset names are simulated presentation metadata")

col1, col2 = st.columns([2, 1])

with col1:
    selected_alert = st.selectbox("Select Alert", options=filtered_df['alert_id'].tolist(), 
                                   format_func=lambda x: f"{x[:8]}... - {filtered_df[filtered_df['alert_id']==x]['predicted_class'].values[0]} (Risk: {filtered_df[filtered_df['alert_id']==x]['risk_score'].values[0]})")
    
    if selected_alert:
        alert_row = filtered_df[filtered_df['alert_id'] == selected_alert].iloc[0]
        
        with st.expander("Alert Details", expanded=True):
            c1, c2, c3 = st.columns(3)
            c1.metric("Risk Score", alert_row['risk_score'])
            c2.metric("Severity", alert_row['severity'])
            c3.metric("Confidence", f"{alert_row['confidence']:.4f}")
            
            st.text(f"Predicted Class: {alert_row['predicted_class']}")
            st.text(f"Status: {alert_row['status']}")
            st.text(f"Asset (Simulated): {alert_row['asset']}")
            st.text(f"Sensor ID: {alert_row['sensor_id']}")
            st.text(f"Created: {alert_row['created_at']}")

with col2:
    st.subheader("Update Status")
    current_status = filtered_df[filtered_df['alert_id'] == selected_alert]['status'].values[0] if selected_alert else "New"
    
    new_status = st.selectbox("Change Status", 
                              options=settings.ALERT_STATUSES,
                              index=settings.ALERT_STATUSES.index(current_status) if current_status in settings.ALERT_STATUSES else 0)
    
    analyst = st.text_input("Analyst Name", value=settings.DEFAULT_ANALYST)
    comment = st.text_area("Comment/Notes", placeholder="Add investigation notes...")
    
    if st.button("Update Alert", type="primary"):
        conn = db.get_connection()
        now = datetime.now(timezone.utc).isoformat()
        
        # Update alert
        conn.execute("UPDATE alerts SET status = ?, updated_at = ? WHERE alert_id = ?",
                     (new_status, now, selected_alert))
        
        # Log to audit trail
        conn.execute("""
            INSERT INTO alert_events (alert_id, timestamp, actor, action, old_status, new_status, note)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (selected_alert, now, analyst, "status_change", current_status, new_status, comment))
        
        conn.commit()
        conn.close()
        st.success(f"Alert {selected_alert[:8]}... updated to {new_status}")
        st.rerun()
    
    st.info("Valid transitions enforced by policy. All actions are logged.")
