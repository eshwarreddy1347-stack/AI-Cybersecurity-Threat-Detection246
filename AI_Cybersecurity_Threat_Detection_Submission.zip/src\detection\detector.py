"""Main detection engine - generates predictions and alerts from model."""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import uuid

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import settings
from src.data.loader import FEATURE_COLUMNS
from src.features.preprocess import transform_frame
from src.models.train import load_bundle
from src.detection.scoring import compute_risk_score, should_generate_alert
from src.detection.evidence import generate_evidence


class ThreatDetector:
    """Threat detector using trained HistGradientBoosting model."""
    
    def __init__(self, bundle_path: str | Path | None = None):
        if bundle_path is None:
            bundle_path = settings.ARTIFACT_DIR / "stage3_final" / "model_hgb_full.joblib"
        self.bundle = load_bundle(bundle_path)
        self.preprocessor = self.bundle["preprocessor"]
        self.estimator = self.bundle["estimator"]
        self.classes = self.bundle["classes"]
        self.feature_names = self.bundle["feature_names"]
        self.global_importance = self.bundle.get("global_importance", {})
        self.model_name = self.bundle.get("model_name", "unknown")
    
    def predict(self, df: pd.DataFrame) -> pd.DataFrame:
        """Generate predictions for dataframe of raw NSL-KDD features."""
        # Ensure we have feature columns
        missing = [col for col in FEATURE_COLUMNS if col not in df.columns]
        if missing:
            raise ValueError(f"Missing feature columns: {missing}")
        
        X = df[FEATURE_COLUMNS].copy()
        X_transformed = transform_frame(self.preprocessor, X)
        
        predictions = self.estimator.predict(X_transformed)
        probabilities = self.estimator.predict_proba(X_transformed)
        
        results = df.copy()
        results["predicted_class"] = predictions
        results["confidence"] = [float(prob[np.where(self.estimator.classes_ == pred)[0][0]]) 
                                for pred, prob in zip(predictions, probabilities)]
        
        # Attack probability = 1 - P(Normal)
        if "Normal" in self.estimator.classes_:
            normal_idx = list(self.estimator.classes_).index("Normal")
            results["attack_probability"] = 1.0 - probabilities[:, normal_idx]
        else:
            results["attack_probability"] = 1.0
        
        return results
    
    def generate_alerts(self, df: pd.DataFrame, generate_all_attacks: bool = False) -> list[dict[str, Any]]:
        """Generate alerts from predictions."""
        predictions = self.predict(df)
        alerts = []
        
        for idx, row in predictions.iterrows():
            pred_class = str(row["predicted_class"])
            confidence = float(row["confidence"])
            
            risk_info = compute_risk_score(pred_class, confidence, row)
            risk_score = risk_info["risk_score"]
            severity = risk_info["severity"]
            
            if not should_generate_alert(pred_class, risk_score) and not generate_all_attacks:
                if pred_class == "Normal":
                    continue
            
            evidence = generate_evidence(pred_class, confidence, row, self.global_importance)
            
            alert = {
                "alert_id": str(uuid.uuid4()),
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "predicted_class": pred_class,
                "confidence": round(confidence, 4),
                "attack_probability": round(float(row["attack_probability"]), 4),
                "risk_score": risk_score,
                "severity": severity,
                "status": "New",
                "asset": evidence["simulated_info"]["asset"],
                "sensor_id": evidence["simulated_info"]["sensor_id"],
                "evidence": json.dumps(evidence),
                "raw_features": json.dumps({col: (int(row[col]) if isinstance(row[col], (np.integer,)) else float(row[col]) if isinstance(row[col], (np.floating,)) else str(row[col])) 
                                           for col in FEATURE_COLUMNS}),
                "risk_components": json.dumps(risk_info["components"]),
                "model_name": self.model_name,
            }
            alerts.append(alert)
        
        return alerts
