"""Overview Dashboard - Key metrics and threat landscape"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from pathlib import Path
import sys
import json

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from config import settings
from src.alerts.db import AlertDB

st.set_page_config(page_title="Overview Dashboard", page_icon="📊", layout="wide")

st.title("📊 Overview Dashboard")
st.caption("Key metrics and threat landscape at a glance")

db = AlertDB()
alerts = db.get_all_alerts(limit=10000)

if not alerts:
    st.warning("⚠️ No alerts found in database. Use the detection pipeline to generate alerts.")
    st.stop()

df = pd.DataFrame(alerts)
df['created_at'] = pd.to_datetime(df['created_at'])

# KPI Cards
col1, col2, col3, col4, col5 = st.columns(5)

total = len(df)
critical = len(df[df['severity'] == 'Critical'])
high = len(df[df['severity'] == 'High'])
attacks = len(df[df['predicted_class'] != 'Normal'])
new_status = len(df[df['status'] == 'New'])

col1.metric("Total Alerts", total)
col2.metric("Critical", critical, delta=f"{critical/total*100:.1f}%" if total > 0 else "0%")
col3.metric("High Severity", high)
col4.metric("Attacks Detected", attacks)
col5.metric("New/Unassigned", new_status)

st.divider()

# Charts
col1, col2 = st.columns(2)

with col1:
    st.subheader("Attack Categories Distribution")
    attack_df = df[df['predicted_class'] != 'Normal']
    if not attack_df.empty:
        cat_counts = attack_df['predicted_class'].value_counts()
        fig = px.pie(values=cat_counts.values, names=cat_counts.index,
                     color_discrete_sequence=px.colors.qualitative.Set3,
                     hole=0.4)
        fig.update_traces(textposition='inside', textinfo='percent+label')
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No attack alerts")

with col2:
    st.subheader("Severity Distribution")
    sev_counts = df['severity'].value_counts()
    colors = {'Critical': '#d62728', 'High': '#ff7f0e', 'Medium': '#ffbb78', 'Low': '#98df8a'}
    fig = px.bar(x=sev_counts.index, y=sev_counts.values,
                 color=sev_counts.index, color_discrete_map=colors,
                 labels={'x': 'Severity', 'y': 'Count'})
    fig.update_layout(height=400, showlegend=False)
    st.plotly_chart(fig, use_container_width=True)

st.divider()

# Alert Timeline
st.subheader("Alert Timeline")
df_time = df.copy()
df_time['date'] = df_time['created_at'].dt.date
timeline = df_time.groupby(['date', 'severity']).size().reset_index(name='count')
fig = px.line(timeline, x='date', y='count', color='severity',
              color_discrete_map=colors, markers=True,
              labels={'date': 'Date', 'count': 'Number of Alerts'})
fig.update_layout(height=350)
st.plotly_chart(fig, use_container_width=True)

st.divider()

# Recent Critical Alerts
st.subheader("🚨 Recent Critical Alerts")
critical_df = df[df['severity'] == 'Critical'].sort_values('created_at', ascending=False).head(10)
if not critical_df.empty:
    display_cols = ['alert_id', 'created_at', 'predicted_class', 'confidence', 'risk_score', 'status', 'asset']
    st.dataframe(critical_df[display_cols], use_container_width=True, hide_index=True)
else:
    st.success("No critical alerts")
