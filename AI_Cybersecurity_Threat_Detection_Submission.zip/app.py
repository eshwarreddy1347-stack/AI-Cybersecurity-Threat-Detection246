"""AI-Based Cybersecurity Threat Detection and Analysis - Main Dashboard
Streamlit entry point for the B.Tech project.
"""

import streamlit as st
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from config import settings
from src.alerts.db import AlertDB

st.set_page_config(
    page_title="AI-Based Cybersecurity Threat Detection",
    page_icon="🔒",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Initialize DB
db = AlertDB()

# Sidebar
with st.sidebar:
    st.image("https://img.icons8.com/color/96/cyber-security.png", width=80)
    st.title("CyberSec AI")
    st.caption("Threat Detection & Analysis")
    st.divider()
    st.info("**Scope:** Offline analysis only. No live traffic capture, no blocking/modification.")
    st.divider()
    alert_count = db.get_alert_count()
    st.metric("Total Alerts Stored", alert_count)
    st.caption(f"DB: {settings.DB_PATH}")

# Main page
st.title("🛡️ AI-Based Cybersecurity Threat Detection and Analysis")
st.subheader("B.Tech Project Dashboard")

st.markdown("""
### Welcome

This dashboard provides a comprehensive view of network threat detection using Machine Learning on the **NSL-KDD** dataset.

**Features:**
- **Overview Dashboard** - Key metrics and threat landscape
- **Alert Queue** - Manage security alerts with status tracking
- **Alert Details** - Deep dive into individual alerts with evidence
- **Attack Analysis** - Analyze attack patterns and trends
- **Model Performance** - View trained model evaluation results
- **About Project** - Project information and methodology

**Safety Notice:** This is an offline analysis tool. Asset names shown are **simulated presentation metadata** as NSL-KDD contains no IP addresses.
""")

st.divider()

# Quick stats
col1, col2, col3, col4 = st.columns(4)
alerts = db.get_all_alerts(limit=1000)
if alerts:
    import pandas as pd
    df_alerts = pd.DataFrame(alerts)
    critical = len(df_alerts[df_alerts['severity'] == 'Critical'])
    high = len(df_alerts[df_alerts['severity'] == 'High'])
    new_alerts = len(df_alerts[df_alerts['status'] == 'New'])
    
    col1.metric("Critical Alerts", critical, delta=None)
    col2.metric("High Severity", high, delta=None)
    col3.metric("New Alerts", new_alerts, delta=None)
    col4.metric("Total Alerts", len(df_alerts), delta=None)
else:
    col1.metric("Critical Alerts", 0)
    col2.metric("High Severity", 0)
    col3.metric("New Alerts", 0)
    col4.metric("Total Alerts", 0)
    st.info("No alerts in database yet. Generate alerts using the detection pipeline.")

st.divider()
st.caption("Navigate using the sidebar pages to explore the dashboard.")
