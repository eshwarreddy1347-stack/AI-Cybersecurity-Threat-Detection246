# Screenshot Guide for Dashboard

Capture the following 6 screenshots to demonstrate the dashboard functionality:

## 1. Overview Dashboard (`01_overview_dashboard.png`)
**Page:** Overview Dashboard  
**What to capture:**
- KPI cards (Total Alerts, Critical, High Severity, Attacks Detected, New/Unassigned)
- Attack Categories Distribution pie chart
- Severity Distribution bar chart
- Alert Timeline line chart
- Recent Critical Alerts table

## 2. Alert Queue (`02_alert_queue.png`)
**Page:** Alert Queue  
**What to capture:**
- Filter options (Status, Severity, Attack Class, Asset)
- Alert list table with all columns
- CSV export button
- Alert Management section with status update controls

## 3. Alert Details (`03_alert_details.png`)
**Page:** Alert Details  
**What to capture:**
- Alert header with ID, severity, risk score, status
- Basic Information section
- Evidence tabs (Red Flags, Top Features, Dataset Evidence, Simulated Info)
- Risk Score Breakdown
- Audit Trail

## 4. Attack Analysis (`04_attack_analysis.png`)
**Page:** Attack Analysis  
**What to capture:**
- Attack Statistics cards
- Attacks by Type bar chart
- Attack Severity Distribution sunburst
- Risk Score Distribution by Attack Type box plot
- Attack Trends Over Time line chart
- Top Targeted Assets (Simulated) chart

## 5. Model Performance (`05_model_performance.png`)
**Page:** Model Performance  
**What to capture:**
- Model Information
- Overall Performance metrics
- Binary Attack Detection metrics
- Per-Class Performance table and chart
- Confusion Matrix heatmap

## 6. About Project (`06_about_project.png`)
**Page:** About Project  
**What to capture:**
- Project Overview
- Dataset information
- Methodology sections
- Risk Scoring Model
- Safety & Scope warning
- Development Stages table

## Instructions
1. Start the dashboard: `.\.venv\Scripts\python.exe -m streamlit run app.py`
2. Navigate to each page in order
3. Ensure data is visible (generate some alerts if needed using the detection pipeline)
4. Capture full-page screenshots
5. Save with the exact filenames listed above in this folder
6. Update README.md if needed (references already added)
