# Preprocessing explained (for presentation and viva)

This document explains, in plain language, what `src/features/preprocess.py`
does and why. No maths beyond percentages and averages is required.

---

## 1. Why preprocess at all?

A machine-learning model can only do arithmetic. It cannot read the word
`"http"` or understand that `src_bytes = 5` and `src_bytes = 5,000,000`
are very different. Preprocessing converts every connection record into a
row of numbers the model can compare.

The raw data has three kinds of columns:

| Kind | Example | Problem | Solution |
|---|---|---|---|
| Continuous numbers | `src_bytes`, `duration`, `count` | Huge range differences; a few very large values dominate | `log1p` + `StandardScaler` |
| Categories (text) | `protocol_type = "tcp"`, `service = "http"`, `flag = "SF"` | Models cannot multiply words | One-hot encoding |
| Metadata | `label` (the answer), `difficulty` | Not a signal; `difficulty` would leak benchmark info | Removed from `X` |

---

## 2. Step 1 — Separate inputs from answers

`build_xy()` produces:

- **X** — the 41 feature columns only. `label` and `difficulty` are excluded.
  Including `difficulty` would be a form of cheating: it is metadata added by
  the dataset authors, not something a real sensor observes.
- **y_multi** — the 5-class answer: Normal / DoS / Probe / R2L / U2R.
- **y_bin** — the binary answer: `0` = Normal, `1` = Attack.

Two targets exist because the dashboard needs both questions answered:
*"is this suspicious?"* (binary) and *"what kind of attack is it?"* (multiclass).

---

## 3. Step 2 — Compress huge numbers with log1p

Byte counts and connection counts are extremely skewed. Most connections send
a few hundred bytes; a few send millions. On a raw scale, the model would
think the difference between 100 and 1,000 bytes matters more than the
difference between 1,000,000 and 1,001,000 bytes — which is backwards.

`log1p(x) = log(1 + x)` squashes large values while keeping small ones
distinguishable and keeping zero as zero. After this step, the numbers are
on a comparable scale.

**Viva answer:** *"We use log1p because the traffic features are heavy-tailed.
It reduces the influence of extreme outliers without deleting them. The `+1`
lets us safely transform zeros."*

---

## 4. Step 3 — Standardise with StandardScaler

After `log1p`, columns still have different averages and spreads. The scaler
converts every column to roughly *"how many standard deviations above or
below the training average is this value?"*

```
z = (value - training_mean) / training_standard_deviation
```

This matters most for Logistic Regression, which is sensitive to scale.
Tree-based models do not need it, but applying it does them no harm — and it
keeps one pipeline for all models, which is simpler and fairer to compare.

**Viva answer:** *"The scaler is fitted only on training data. If we used the
test set's mean and standard deviation, the test set would influence the
model — that is data leakage."*

---

## 5. Step 4 — One-hot encode categorical fields

One-hot encoding turns one text column into several 0/1 columns:

```
service = "http"   ->  service_http=1, service_ftp=0, service_smtp=0, ...
service = "ftp"    ->  service_http=0, service_ftp=1, service_smtp=0, ...
```

Why not simply number them 1, 2, 3? Because the model would assume
`ftp (2) > http (1)`, an ordering that does not exist. One-hot avoids
inventing false relationships.

**Unknown categories:** the encoder is created with
`handle_unknown="ignore"`. If a future upload contains a service the model
has never seen, that row's one-hot block is all zeros instead of crashing.
This is tested directly (`test_unseen_category_does_not_break_transform`).

**Viva answer:** *"Unknown categories are ignored, producing an all-zero
encoding for that field. The prediction still runs; the model simply has no
evidence from that feature."*

---

## 6. Step 5 — Fit on train, transform test

The pipeline has two verbs:

- `fit(X_train)` — *learn* the averages, spreads and category list.
- `transform(X)` — *apply* those learned values.

Only the training split is ever passed to `fit`. The test split, uploaded
CSVs and dashboard input are only ever passed to `transform`. The fitted
object is stored once as `artifacts/preprocessor.joblib`, so the app never
re-learns at runtime and results are reproducible.

**How leakage is proven in the test suite.** A tiny training set has
`dst_bytes = [0, 10, 20]`; the test row has `dst_bytes = 1000`. The test
recomputes the expected scaled value by hand from the **training** mean and
standard deviation and asserts the pipeline matches. If the test row had been
used during fitting, the result would be dramatically different and the test
would fail.

---

## 7. What the numbers mean

| Quantity | Value |
|---|---|
| Raw features | 41 |
| Numeric block after preprocessing | 38 |
| One-hot block | 84 (3 protocol + 70 service + 11 flag values) |
| Total encoded features | **122** |
| Train matrix | 125,973 × 122 |
| Test matrix | 22,544 × 122 |
| Missing values after transform | 0 |

---

## 8. Likely viva questions

**Q: Why 122 features instead of 41?**
One-hot encoding expands three text columns into 84 binary columns. The
information is the same; the representation is machine-readable.

**Q: Doesn't one-hot create too many columns?**
84 is small. For very high-cardinality fields (hundreds of values) we would
use frequency or target encoding, or group rare values. NSL-KDD's `service`
has only 70 distinct values across 126k rows, so one-hot is appropriate.

**Q: Why not delete duplicates?**
They are part of the official benchmark. Removing them would change the
comparison baseline and could bias the reported score. We report the count
(16 train, 57 test) and the 654 cross-split overlaps openly instead.

**Q: Why not balance the classes by generating fake rows?**
Synthetic minority samples (SMOTE) are hard to justify in security: invented
attack traffic may not resemble real attacks. We use class weighting in the
model, which changes the loss function rather than the data.

**Q: What happens if an uploaded CSV has a negative byte count?**
`assert_non_negative()` rejects it before `log1p` can produce an undefined
value. Bad input fails loudly with a clear message instead of silently
producing NaN.

**Q: Is the scaler fitted on the whole dataset?**
No. Only on the training split. The test suite contains an explicit
leakage test for this.

**Q: Why save the preprocessor to a file?**
So training, the CLI and the Streamlit app all use the exact same
transformation. Re-fitting at runtime would risk different category lists or
scales and make alerts irreproducible.
