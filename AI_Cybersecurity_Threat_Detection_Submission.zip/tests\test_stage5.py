"""Tests for Stage 5: Dashboard functionality"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from config import settings
from src.alerts.db import AlertDB


def test_alert_db_connection():
    """Dashboard should connect to existing SQLite database."""
    db = AlertDB()
    assert db.get_alert_count() >= 0


def test_dashboard_loads_metrics():
    """Dashboard should load final Stage 3 model and metrics."""
    metrics_path = settings.ARTIFACT_DIR / "stage3_final" / "metrics_hgb_full.json"
    assert metrics_path.exists()
    
    with open(metrics_path) as f:
        data = json.load(f)
    
    assert data['selected_model'] == 'hist_gradient_boosting'
    assert 'test' in data
    assert 'macro_f1' in data['test']['metrics']


def test_alert_management_functions():
    """Test alert management functions."""
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
        db_path = f.name
    
    db = AlertDB(db_path)
    
    alert = {
        "alert_id": "test-001",
        "timestamp": "2026-01-01T00:00:00+00:00",
        "predicted_class": "DoS",
        "confidence": 0.95,
        "attack_probability": 0.98,
        "risk_score": 75,
        "severity": "High",
        "status": "New",
        "asset": "web-01",  # simulated
        "sensor_id": "sensor-demo-01",
        "evidence": json.dumps({"test": True}),
        "raw_features": json.dumps({}),
        "risk_components": json.dumps({}),
        "model_name": "hist_gradient_boosting",
    }
    
    db.insert_alert(alert)
    assert db.get_alert_count() == 1
    
    alerts = db.get_all_alerts()
    assert len(alerts) == 1
    assert alerts[0]['severity'] == 'High'
    assert alerts[0]['status'] == 'New'
    
    # Test status update
    conn = db.get_connection()
    conn.execute("UPDATE alerts SET status = ? WHERE alert_id = ?", ("Acknowledged", "test-001"))
    conn.commit()
    conn.close()
    
    alerts = db.get_all_alerts()
    assert alerts[0]['status'] == 'Acknowledged'


def test_audit_log_recording():
    """Test that analyst actions are recorded in audit log."""
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
        db_path = f.name
    
    db = AlertDB(db_path)
    
    alert = {
        "alert_id": "test-002",
        "timestamp": "2026-01-01T00:00:00+00:00",
        "predicted_class": "Probe",
        "confidence": 0.9,
        "attack_probability": 0.92,
        "risk_score": 55,
        "severity": "Medium",
        "status": "New",
        "asset": "dns-01",
        "sensor_id": "sensor-demo-01",
        "evidence": json.dumps({}),
        "raw_features": json.dumps({}),
        "risk_components": json.dumps({}),
        "model_name": "hist_gradient_boosting",
    }
    
    db.insert_alert(alert)
    
    conn = db.get_connection()
    conn.execute("""
        INSERT INTO alert_events (alert_id, timestamp, actor, action, old_status, new_status, note)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, ("test-002", "2026-01-01T01:00:00+00:00", "analyst1", "status_change", "New", "Investigating", "Looking into this"))
    conn.commit()
    
    events = conn.execute("SELECT * FROM alert_events WHERE alert_id = ?", ("test-002",)).fetchall()
    conn.close()
    
    assert len(events) == 1
    assert dict(events[0])['actor'] == "analyst1"
    assert dict(events[0])['action'] == "status_change"


def test_simulated_asset_labeling():
    """Ensure simulated asset information is clearly labeled."""
    from src.detection.evidence import generate_evidence
    features = {"protocol_type": "tcp", "service": "http", "flag": "SF", "src_bytes": 100, "dst_bytes": 200}
    evidence = generate_evidence("DoS", 0.95, features)
    assert "simulated" in evidence["simulated_info"]["note"].lower()


def test_model_not_modified():
    """Ensure trained model not modified - check file exists."""
    model_path = settings.ARTIFACT_DIR / "stage3_final" / "model_hgb_full.joblib"
    assert model_path.exists()
    
    metrics_path = settings.ARTIFACT_DIR / "stage3_final" / "metrics_hgb_full.json"
    with open(metrics_path) as f:
        data = json.load(f)
    # Should still have original results
    assert data['test']['metrics']['macro_f1'] == pytest.approx(0.6431153708444356)
