"""Configuration package for the threat-detection application."""

from config import settings

__all__ = ["settings"]
