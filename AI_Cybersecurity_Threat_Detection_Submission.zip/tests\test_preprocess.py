"""Tests for the Stage 2 feature pipeline."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from config import settings
from src.data.loader import FEATURE_COLUMNS, NUMERIC_COLUMNS
from src.features.preprocess import (
    assert_non_negative,
    build_preprocessor,
    build_xy,
    load_preprocessor,
    save_preprocessor,
    transform_frame,
    unseen_categories,
)

SPLITS_PRESENT = all(
    (settings.RAW_DIR / filename).is_file()
    for filename in settings.DATASET_FILES.values()
)
ARTIFACT_PRESENT = (settings.ARTIFACT_DIR / "preprocessor.joblib").is_file()


def _frame(rows: int = 3, service: str = "http") -> pd.DataFrame:
    """Build a minimal but complete raw-feature frame."""
    data: dict[str, list[object]] = {}
    for column in FEATURE_COLUMNS:
        if column == "protocol_type":
            data[column] = ["tcp"] * rows
        elif column == "service":
            data[column] = [service] * rows
        elif column == "flag":
            data[column] = ["SF"] * rows
        else:
            data[column] = [0] * rows
    return pd.DataFrame(data)


def test_transform_shape_and_no_nan():
    preprocessor = build_preprocessor()
    train = _frame(6)
    train.loc[0:2, "service"] = "ftp"  # force a second one-hot category
    preprocessor.fit(train)
    matrix = transform_frame(preprocessor, train)
    assert len(matrix) == 6
    assert matrix.isna().sum().sum() == 0
    # 38 numeric + 4 one-hot (2 services, 1 protocol, 1 flag)
    assert matrix.shape[1] == 42
    assert list(matrix.columns) == list(preprocessor.get_feature_names_out())


def test_unseen_category_does_not_break_transform():
    preprocessor = build_preprocessor()
    preprocessor.fit(_frame(4, service="http"))
    transformed = transform_frame(preprocessor, _frame(2, service="never_seen_svc"))
    assert transformed.shape[0] == 2
    assert transformed.isna().sum().sum() == 0
    assert unseen_categories(preprocessor, _frame(2, service="never_seen_svc"))[
        "service"
    ] == 2


def test_scaler_statistics_come_from_training_data_only():
    """A huge test value must not influence mean/std (leakage guard)."""
    train = _frame(3)
    train["dst_bytes"] = [0, 10, 20]
    test = _frame(1)
    test["dst_bytes"] = [1000]

    preprocessor = build_preprocessor()
    preprocessor.fit(train)
    matrix = transform_frame(preprocessor, test)

    train_log = np.log1p(np.array([0, 10, 20], dtype=float))
    expected = (np.log1p(1000) - train_log.mean()) / train_log.std(ddof=0)
    assert matrix["numeric__dst_bytes"].iloc[0] == pytest.approx(expected)
    # With test leakage the scaled value would be far smaller.
    assert abs(matrix["numeric__dst_bytes"].iloc[0]) > 1.0


def test_negative_numeric_values_are_rejected():
    frame = _frame(2)
    frame.loc[0, "src_bytes"] = -1
    with pytest.raises(ValueError, match="negative values"):
        assert_non_negative(frame)


def test_build_xy_targets():
    frame = _frame(3)
    frame["category"] = ["Normal", "DoS", "U2R"]
    features, multi, binary = build_xy(frame)
    assert list(features.columns) == FEATURE_COLUMNS
    assert multi.tolist() == ["Normal", "DoS", "U2R"]
    assert binary.tolist() == [0, 1, 1]


def test_build_xy_requires_labels():
    with pytest.raises(ValueError, match="label_connections"):
        build_xy(_frame(2))


def test_save_and_load_roundtrip(tmp_path):
    preprocessor = build_preprocessor()
    preprocessor.fit(_frame(4))
    path = save_preprocessor(preprocessor, tmp_path / "pre.joblib")
    restored = load_preprocessor(path)
    left = transform_frame(preprocessor, _frame(2))
    right = transform_frame(restored, _frame(2))
    pd.testing.assert_frame_equal(left, right)


def test_missing_artifact_has_actionable_error(tmp_path):
    with pytest.raises(FileNotFoundError, match="prepare_features"):
        load_preprocessor(tmp_path / "missing.joblib")


@pytest.mark.skipif(not SPLITS_PRESENT, reason="NSL-KDD files not downloaded")
def test_all_numeric_features_are_non_negative():
    from src.data.loader import load_dataset

    for frame in load_dataset().values():
        assert (frame[NUMERIC_COLUMNS].min() >= 0).all()


@pytest.mark.skipif(
    not (SPLITS_PRESENT and ARTIFACT_PRESENT),
    reason="preprocessor artifact not built",
)
def test_saved_artifact_transforms_official_test_split():
    from src.data.loader import load_split

    preprocessor = load_preprocessor()
    test = load_split("test")
    features, _, _ = build_xy(test)
    matrix = transform_frame(preprocessor, features)
    assert matrix.shape[0] == len(test)
    assert matrix.isna().sum().sum() == 0
    assert list(matrix.columns) == list(
        preprocessor.get_feature_names_out()
    )
