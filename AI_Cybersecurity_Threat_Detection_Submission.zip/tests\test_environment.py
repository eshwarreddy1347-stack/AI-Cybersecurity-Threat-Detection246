"""Sanity tests for the Stage 0 configuration."""

from config import settings


def test_every_class_has_severity_weight():
    assert set(settings.CLASS_ORDER) == set(settings.SEVERITY_WEIGHTS)


def test_severity_weights_within_range():
    assert all(0 <= weight <= 100 for weight in settings.SEVERITY_WEIGHTS.values())


def test_attack_labels_map_to_known_classes():
    assert set(settings.ATTACK_CATEGORY_MAP.values()) <= set(settings.CLASS_ORDER)


def test_dataset_column_count():
    # 41 features + label + difficulty
    assert len(settings.NSL_KDD_COLUMNS) == 43
    assert settings.NSL_KDD_COLUMNS[-2:] == ["label", "difficulty"]


def test_transitions_reference_known_statuses():
    known = set(settings.ALERT_STATUSES)
    for source, targets in settings.STATUS_TRANSITIONS.items():
        assert source in known
        assert set(targets) <= known


def test_thresholds_are_sane():
    assert 0 < settings.ALERT_CONFIDENCE_THRESHOLD < 1
    assert 0 < settings.RISK_ALERT_THRESHOLD < 100
