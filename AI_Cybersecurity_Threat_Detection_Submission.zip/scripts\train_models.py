"""Train and evaluate the threat-detection models.

Usage:
    python scripts\\train_models.py                  # compare all candidates (full)
    python scripts\\train_models.py --quick          # fast smoke run
    python scripts\\train_models.py --dev           # dev mode with smaller models
    python scripts\\train_models.py --dev-sample-frac 0.2  # stratified sample for speed
    python scripts\\train_models.py --model random_forest
    python scripts\\train_models.py --output-dir artifacts\\experiment-01

Writes into ``artifacts/``:
    model.joblib             preprocessor + estimator + baseline + importance
    metrics.json             validation comparison and final test report
    feature_importance.csv   ranked global importance
    confusion_matrix.json    official test confusion matrix
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.models.train import CANDIDATE_NAMES, train_all  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument(
        "--model",
        choices=["auto", *CANDIDATE_NAMES],
        default="auto",
        help="train one candidate, or 'auto' to compare all (default)",
    )
    parser.add_argument(
        "--quick",
        action="store_true",
        help="smaller ensembles for a fast smoke run (not for final numbers)",
    )
    parser.add_argument(
        "--dev",
        action="store_true",
        help="development mode with reduced model sizes (RF=50, LR limited iters)",
    )
    parser.add_argument(
        "--dev-sample-frac",
        type=float,
        default=1.0,
        help="stratified fraction of training data for dev (e.g., 0.2). Test set untouched.",
    )
    parser.add_argument(
        "--rf-trees",
        type=int,
        default=None,
        help="override Random Forest n_estimators (e.g., 50)",
    )
    parser.add_argument(
        "--lr-max-iter",
        type=int,
        default=None,
        help="override Logistic Regression max_iter",
    )
    parser.add_argument(
        "--hgb-max-iter",
        type=int,
        default=None,
        help="override HistGradientBoosting max_iter",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="artifact directory (default: artifacts/)",
    )
    args = parser.parse_args(argv)

    model_names = None if args.model == "auto" else [args.model]
    dev_mode = args.dev or args.dev_sample_frac < 1.0
    payload = train_all(
        model_names=model_names,
        quick=args.quick,
        dev=dev_mode,
        dev_sample_frac=args.dev_sample_frac,
        rf_trees=args.rf_trees,
        lr_max_iter=args.lr_max_iter,
        hgb_max_iter=args.hgb_max_iter,
        output_dir=args.output_dir,
    )

    print()
    print("=" * 72)
    print(f"Mode            : {payload.get('mode', 'full')} (sample_based={payload.get('sample_based', False)})")
    print(f"Selected model  : {payload['selected_model']}")
    if payload.get("sample_based") or payload["test"].get("untouched") and "metrics" not in payload["test"]:
        print("Test evaluation : SKIPPED (official test set untouched)")
    else:
        test_metrics = payload["test"]["metrics"]
        print(f"Test macro-F1   : {test_metrics['macro_f1']:.4f}")
        print(
            f"Attack recall   : {test_metrics['binary_attack']['recall']:.4f}  "
            f"(FPR {test_metrics['binary_attack']['false_positive_rate']:.4f})"
        )
    print("=" * 72)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
