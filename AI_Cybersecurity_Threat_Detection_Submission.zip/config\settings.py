"""Central configuration for the threat-detection application.

Every tunable value lives here so behaviour can be explained and defended
without hunting through the codebase. Nothing in this module performs I/O;
call ``ensure_directories()`` once at start-up if you need the folders to exist.

Safety note
-----------
This project is analysis-only. It never captures live traffic and never
blocks, isolates or otherwise acts on a host or network. All dataset-derived
"assets" below are presentation metadata for the dashboard and are clearly
labelled as simulated in the UI.
"""

from __future__ import annotations

from pathlib import Path
from typing import Final

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
PROJECT_ROOT: Final[Path] = Path(__file__).resolve().parents[1]

DATA_DIR: Final[Path] = PROJECT_ROOT / "data"
RAW_DIR: Final[Path] = DATA_DIR / "raw"
PROCESSED_DIR: Final[Path] = DATA_DIR / "processed"
DEMO_DIR: Final[Path] = DATA_DIR / "demo"
ARTIFACT_DIR: Final[Path] = PROJECT_ROOT / "artifacts"
DB_PATH: Final[Path] = DATA_DIR / "alerts.db"

# ---------------------------------------------------------------------------
# Dataset: NSL-KDD
# ---------------------------------------------------------------------------
DATASET_NAME: Final[str] = "NSL-KDD"

DATASET_FILES: Final[dict[str, str]] = {
    "train": "KDDTrain+.txt",
    "test": "KDDTest+.txt",
}

DATASET_URLS: Final[dict[str, str]] = {
    "train": (
        "https://raw.githubusercontent.com/defcom17/NSL_KDD/master/"
        "KDDTrain%2B.txt"
    ),
    "test": (
        "https://raw.githubusercontent.com/defcom17/NSL_KDD/master/"
        "KDDTest%2B.txt"
    ),
}

# Expected row counts of the official release. Used to validate downloads.
DATASET_EXPECTED_ROWS: Final[dict[str, int]] = {
    "train": 125_973,
    "test": 22_544,
}

# The 41 NSL-KDD columns in file order, plus the label and difficulty score.
NSL_KDD_COLUMNS: Final[list[str]] = [
    "duration", "protocol_type", "service", "flag", "src_bytes", "dst_bytes",
    "land", "wrong_fragment", "urgent", "hot", "num_failed_logins",
    "logged_in", "num_compromised", "root_shell", "su_attempted",
    "num_root", "num_file_creations", "num_shells", "num_access_files",
    "num_outbound_cmds", "is_host_login", "is_guest_login", "count",
    "srv_count", "serror_rate", "srv_serror_rate", "rerror_rate",
    "srv_rerror_rate", "same_srv_rate", "diff_srv_rate",
    "srv_diff_host_rate", "dst_host_count", "dst_host_srv_count",
    "dst_host_same_srv_rate", "dst_host_diff_srv_rate",
    "dst_host_same_src_port_rate", "dst_host_srv_diff_host_rate",
    "dst_host_serror_rate", "dst_host_srv_serror_rate",
    "dst_host_rerror_rate", "dst_host_srv_rerror_rate",
    "label", "difficulty",
]

CATEGORICAL_FEATURES: Final[list[str]] = ["protocol_type", "service", "flag"]

# The 41 raw attack labels collapse into these five classes.
CLASS_ORDER: Final[list[str]] = ["Normal", "DoS", "Probe", "R2L", "U2R"]

ATTACK_CATEGORY_MAP: Final[dict[str, str]] = {
    # DoS
    "back": "DoS", "land": "DoS", "neptune": "DoS", "pod": "DoS",
    "smurf": "DoS", "teardrop": "DoS", "mailbomb": "DoS", "apache2": "DoS",
    "processtable": "DoS", "udpstorm": "DoS", "worm": "DoS",
    # Probe
    "satan": "Probe", "ipsweep": "Probe", "nmap": "Probe", "portsweep": "Probe",
    "mscan": "Probe", "saint": "Probe",
    # R2L
    "guess_passwd": "R2L", "ftp_write": "R2L", "imap": "R2L",
    "phf": "R2L", "multihop": "R2L", "warezmaster": "R2L",
    "warezclient": "R2L", "spy": "R2L", "xlock": "R2L", "xsnoop": "R2L",
    "snmpguess": "R2L", "snmpgetattack": "R2L", "httptunnel": "R2L",
    "sendmail": "R2L", "named": "R2L",
    # U2R
    "buffer_overflow": "U2R", "loadmodule": "U2R", "rootkit": "U2R",
    "perl": "U2R", "sqlattack": "U2R", "xterm": "U2R", "ps": "U2R",
    # Benign
    "normal": "Normal",
}

# ---------------------------------------------------------------------------
# Model / split
# ---------------------------------------------------------------------------
RANDOM_STATE: Final[int] = 42
TEST_SIZE: Final[float] = 0.20
CV_FOLDS: Final[int] = 5
PRIMARY_METRIC: Final[str] = "macro_f1"

# ---------------------------------------------------------------------------
# Detection & risk scoring
# ---------------------------------------------------------------------------
# A connection becomes "suspicious" when attack probability reaches this value.
ALERT_CONFIDENCE_THRESHOLD: Final[float] = 0.60

# Alerts below this final risk score are suppressed from the queue.
RISK_ALERT_THRESHOLD: Final[int] = 40

# How much each attack class contributes to the base risk (0-100).
# Rationale: U2R = privilege escalation (most severe), R2L = credential
# abuse, DoS = availability, Probe = reconnaissance, Normal = none.
SEVERITY_WEIGHTS: Final[dict[str, int]] = {
    "Normal": 0,
    "Probe": 45,
    "DoS": 70,
    "R2L": 85,
    "U2R": 95,
}

# risk = RISK_CONFIDENCE_WEIGHT * (100 * confidence)
#      + (1 - RISK_CONFIDENCE_WEIGHT) * severity_weight
RISK_CONFIDENCE_WEIGHT: Final[float] = 0.4

# Contextual bumps (capped) for behavioural red flags.
RISK_MODIFIER_CAP: Final[int] = 10
RISK_MODIFIERS: Final[dict[str, int]] = {
    "zero_byte_reply": 5,        # sent data, got nothing back
    "burst_traffic": 5,          # high connection count to one service
    "rejected_connection": 5,    # S0 / REJ / RSTO flags
    "failed_logins": 5,          # one or more failed logins
    "root_shell": 5,             # root shell obtained
}

SEVERITY_BANDS: Final[list[tuple[int, str]]] = [
    (85, "Critical"),
    (70, "High"),
    (40, "Medium"),
    (0, "Low"),
]

# ---------------------------------------------------------------------------
# Alert management
# ---------------------------------------------------------------------------
ALERT_STATUSES: Final[list[str]] = [
    "New",
    "Acknowledged",
    "Investigating",
    "Resolved",
    "False Positive",
]

OPEN_STATUSES: Final[list[str]] = ["New", "Acknowledged", "Investigating"]

# Allowed lifecycle transitions. Anything else is rejected by the service.
STATUS_TRANSITIONS: Final[dict[str, list[str]]] = {
    "New": ["Acknowledged", "Investigating", "False Positive"],
    "Acknowledged": ["Investigating", "Resolved", "False Positive"],
    "Investigating": ["Resolved", "False Positive"],
    "Resolved": [],
    "False Positive": [],
}

# Identical detections inside this window collapse into one alert.
DEDUPE_WINDOW_MINUTES: Final[int] = 15

DEFAULT_ANALYST: Final[str] = "analyst"

# ---------------------------------------------------------------------------
# Presentation metadata (SIMULATED - not part of the dataset)
# ---------------------------------------------------------------------------
# NSL-KDD has no IP addresses. To make alerts readable we map the dataset's
# "service" field to a fictional asset name. The dashboard labels these as
# simulated throughout.
ASSET_MAP: Final[dict[str, str]] = {
    "http": "web-01",
    "https": "web-02",
    "ftp": "ftp-01",
    "ftp_data": "ftp-01",
    "smtp": "mail-01",
    "domain": "dns-01",
    "ssh": "bastion-01",
    "telnet": "legacy-01",
    "pop_3": "mail-02",
    "imap": "mail-02",
    "private": "workstation-pool",
    "eco_i": "iot-sensor-01",
    "ecr_i": "iot-sensor-02",
    "urp_i": "printer-01",
    "auth": "auth-01",
    "finger": "legacy-02",
}
DEFAULT_ASSET: Final[str] = "srv-unknown"

SENSOR_ID: Final[str] = "sensor-demo-01"


def ensure_directories() -> None:
    """Create the runtime folders if they do not exist yet."""
    for directory in (RAW_DIR, PROCESSED_DIR, DEMO_DIR, ARTIFACT_DIR):
        directory.mkdir(parents=True, exist_ok=True)


def asset_for_service(service: str) -> str:
    """Return the simulated asset name for an NSL-KDD service value."""
    return ASSET_MAP.get(str(service).lower(), DEFAULT_ASSET)
