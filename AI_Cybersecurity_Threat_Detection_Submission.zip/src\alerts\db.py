"""SQLite database for alert storage."""

from __future__ import annotations

import json
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import settings


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS alerts (
    alert_id TEXT PRIMARY KEY,
    timestamp TEXT NOT NULL,
    predicted_class TEXT NOT NULL,
    confidence REAL NOT NULL,
    attack_probability REAL NOT NULL,
    risk_score INTEGER NOT NULL,
    severity TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'New',
    asset TEXT,
    sensor_id TEXT,
    evidence TEXT,
    raw_features TEXT,
    risk_components TEXT,
    model_name TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    occurrence_count INTEGER DEFAULT 1,
    dedupe_key TEXT
);

CREATE TABLE IF NOT EXISTS alert_events (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_id TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    old_status TEXT,
    new_status TEXT,
    note TEXT,
    FOREIGN KEY (alert_id) REFERENCES alerts(alert_id)
);

CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);
CREATE INDEX IF NOT EXISTS idx_alerts_severity ON alerts(severity);
CREATE INDEX IF NOT EXISTS idx_alerts_created_at ON alerts(created_at);
CREATE INDEX IF NOT EXISTS idx_alerts_dedupe ON alerts(dedupe_key);
"""


class AlertDB:
    """SQLite database manager for alerts."""
    
    def __init__(self, db_path: str | Path | None = None):
        if db_path is None:
            db_path = settings.DB_PATH
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.init_db()
    
    def init_db(self):
        """Initialize database schema."""
        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript(SCHEMA_SQL)
        conn.commit()
        conn.close()
    
    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def insert_alert(self, alert: dict[str, Any]) -> str:
        """Insert a new alert."""
        conn = self.get_connection()
        now = datetime.now(timezone.utc).isoformat()
        
        # Create dedupe key
        dedupe_key = f"{alert['predicted_class']}:{alert.get('asset','')}:{alert.get('sensor_id','')}"
        
        try:
            conn.execute(
                """
                INSERT INTO alerts (
                    alert_id, timestamp, predicted_class, confidence, attack_probability,
                    risk_score, severity, status, asset, sensor_id, evidence,
                    raw_features, risk_components, model_name, created_at, updated_at,
                    occurrence_count, dedupe_key
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    alert["alert_id"],
                    alert["timestamp"],
                    alert["predicted_class"],
                    alert["confidence"],
                    alert["attack_probability"],
                    alert["risk_score"],
                    alert["severity"],
                    alert.get("status", "New"),
                    alert.get("asset"),
                    alert.get("sensor_id"),
                    alert.get("evidence"),
                    alert.get("raw_features"),
                    alert.get("risk_components"),
                    alert.get("model_name"),
                    now,
                    now,
                    1,
                    dedupe_key,
                ),
            )
            conn.commit()
            return alert["alert_id"]
        finally:
            conn.close()
    
    def get_all_alerts(self, limit: int = 100) -> list[dict[str, Any]]:
        """Get all alerts."""
        conn = self.get_connection()
        try:
            cursor = conn.execute(
                "SELECT * FROM alerts ORDER BY created_at DESC LIMIT ?",
                (limit,),
            )
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
        finally:
            conn.close()
    
    def get_alert_count(self) -> int:
        """Get total number of alerts."""
        conn = self.get_connection()
        try:
            cursor = conn.execute("SELECT COUNT(*) as cnt FROM alerts")
            return cursor.fetchone()["cnt"]
        finally:
            conn.close()
