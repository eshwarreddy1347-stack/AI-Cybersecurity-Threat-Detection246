# AI-Based Cybersecurity Threat Detection and Analysis

A B.Tech project that applies supervised machine learning to the public **NSL-KDD** intrusion-detection dataset and presents the results in a Streamlit analyst dashboard backed by SQLite.

> **Scope and safety.** This is an offline analysis tool. It does not capture live traffic, does not connect to network devices, and cannot block, isolate or modify anything. Alerts are read-and-annotate records only. Asset names shown in the UI are simulated presentation metadata, because NSL-KDD does not contain IP addresses.

## Objectives

- Build a professional cybersecurity dashboard for threat detection and analysis
- Use Python and Machine Learning to detect benign and suspicious network activity
- Classify threats into attack categories (Normal, DoS, Probe, R2L, U2R)
- Calculate transparent risk scores and assign severity levels
- Generate alerts with supporting evidence
- Provide alert management system with audit trail
- Display actual model evaluation results

## Technologies Used

| Technology | Purpose |
|------------|---------|
| Python 3.11+ | Core programming language |
| scikit-learn | Machine learning (HistGradientBoosting) |
| pandas, numpy | Data processing |
| Streamlit | Web dashboard framework |
| SQLite | Alert storage and audit logging |
| Plotly | Data visualization |
| joblib | Model serialization |
| pytest | Testing framework |

## Project Folder Structure

```
AI-Based Cybersecurity Threat Detection/
├── app.py                      # Main Streamlit dashboard
├── pages/                      # Multi-page dashboard
│   ├── 1_📊_Overview_Dashboard.py
│   ├── 2_📋_Alert_Queue.py
│   ├── 3_🔍_Alert_Details.py
│   ├── 4_🎯_Attack_Analysis.py
│   ├── 5_📈_Model_Performance.py
│   └── 6_ℹ️_About_Project.py
├── config/
│   ├── settings.py             # Central configuration
│   └── __init__.py
├── src/
│   ├── data/                   # Dataset loading and download
│   │   ├── download.py
│   │   ├── loader.py
│   │   └── __init__.py
│   ├── features/               # Feature preprocessing
│   │   ├── preprocess.py
│   │   └── __init__.py
│   ├── models/                 # Model training and evaluation
│   │   ├── train.py
│   │   ├── evaluate.py
│   │   └── __init__.py
│   ├── detection/              # Threat detection and risk scoring
│   │   ├── detector.py
│   │   ├── scoring.py
│   │   ├── evidence.py
│   │   └── __init__.py
│   └── alerts/                 # Alert management and storage
│       ├── db.py
│       └── __init__.py
├── scripts/                    # Utility scripts
│   ├── check_env.py
│   ├── train_models.py
│   ├── prepare_features.py
│   └── inspect_data.py
├── tests/                      # Test suite
├── artifacts/                  # Trained models and metrics
│   └── stage3_final/           # Final approved model
├── data/                       # Dataset and database
│   ├── raw/                    # NSL-KDD raw files
│   └── alerts.db               # SQLite alert database
└── requirements.txt
```

## Installation Steps

1. **Clone or download the project**
2. **Create virtual environment:**
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
   *If execution policy blocks activation, use the interpreter directly.*

3. **Install dependencies:**
   ```powershell
   pip install -r requirements.txt
   ```

4. **Verify environment:**
   ```powershell
   .\.venv\Scripts\python.exe scripts\check_env.py
   ```

5. **Download dataset (if not present):**
   ```powershell
   .\.venv\Scripts\python.exe src\data\download.py
   ```

6. **Prepare features:**
   ```powershell
   .\.venv\Scripts\python.exe scripts\prepare_features.py
   ```

## How to Run the Application

**Start the Streamlit dashboard:**
```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

The dashboard will open in your browser at `http://localhost:8501`

**Navigate through pages:**
- Overview Dashboard - Key metrics and threat landscape
- Alert Queue - Manage alerts with filters and status updates
- Alert Details - Deep dive into alert evidence
- Attack Analysis - Analyze attack patterns and trends
- Model Performance - View model evaluation results
- About Project - Project information and methodology

**Run tests:**
```powershell
.\.venv\Scripts\python.exe -m pytest -v
```

## Dataset Information

**NSL-KDD Dataset** (University of New Brunswick)
- **Source:** Public intrusion detection dataset
- **Training:** `data/raw/KDDTrain+.txt` (125,973 records)
- **Testing:** `data/raw/KDDTest+.txt` (22,544 records)
- **Features:** 41 network connection features
- **Attack Categories:**
  - Normal (Benign)
  - DoS (Denial of Service)
  - Probe (Scanning/Reconnaissance)
  - R2L (Remote to Local)
  - U2R (User to Root)

*Note: NSL-KDD does not contain IP addresses. Asset information in this dashboard is simulated presentation metadata.*

## Model Evaluation Results

**Final Model:** HistGradientBoosting (Stage 3)

**Performance on Official Test Set (KDDTest+):**

| Metric | Value |
|--------|-------|
| Accuracy | 0.7818 |
| Balanced Accuracy | 0.5983 |
| Macro-F1 | 0.6431 |
| Weighted-F1 | 0.8177 |
| Attack Precision | 0.9681 |
| Attack Recall | 0.6694 |
| Attack F1 | 0.7915 |
| False Positive Rate | 0.0291 |
| ROC-AUC | 0.9364 |

**Per-Class Performance:**

| Class | Precision | Recall | F1-Score | Support |
|-------|-----------|--------|----------|---------|
| Normal | 0.6897 | 0.9709 | 0.8065 | 9,711 |
| DoS | 0.9620 | 0.7732 | 0.8573 | 7,460 |
| Probe | 0.7987 | 0.7063 | 0.7497 | 2,421 |
| R2L | 0.9901 | 0.2426 | 0.3898 | 2,885 |
| U2R | 0.6667 | 0.2985 | 0.4124 | 67 |

**Final artifacts:** `artifacts/stage3_final/` (model, metrics, confusion matrix)

## Screenshots Section

Screenshots of the dashboard are available in the `docs/screenshots/` folder. See `docs/screenshots/SCREENSHOT_GUIDE.md` for details on capturing them.

The dashboard includes:
- **Overview Dashboard** - KPIs and threat landscape visualization
- **Alert Queue** - Alert management with filtering and CSV export
- **Alert Details** - Evidence and audit trail for each alert
- **Attack Analysis** - Attack patterns and trends
- **Model Performance** - Model evaluation metrics and confusion matrix
- **About Project** - Project information and methodology

## Limitations and Future Scope

### Limitations
- Uses offline NSL-KDD dataset (not real-time network traffic)
- No live packet capture or network monitoring
- Cannot perform automatic blocking or mitigation
- Asset information is simulated (no real IP addresses in dataset)
- Model performance varies on rare attack classes (R2L, U2R)
- Not intended for production security operations

### Future Scope
- Support for real-time network traffic analysis
- Integration with additional intrusion detection datasets
- Enhanced explainable AI features
- Role-based access control
- Email/SMS alert notifications
- Integration with SIEM tools
- Automated threat intelligence enrichment

## Important Notes

- **No Live Traffic:** This tool operates on offline datasets only
- **No Automatic Actions:** Read-and-annotate only, no blocking or modification
- **Academic Project:** Developed for B.Tech project purposes
- **All Tests Passing:** 52 tests pass with no failures
