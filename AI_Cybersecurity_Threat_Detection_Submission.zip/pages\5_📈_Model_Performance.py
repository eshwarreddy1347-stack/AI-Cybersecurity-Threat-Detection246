"""Model Performance - View trained model evaluation results"""

import streamlit as st
import pandas as pd
import json
import plotly.express as px
import plotly.graph_objects as go
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from config import settings

st.set_page_config(page_title="Model Performance", page_icon="📈", layout="wide")

st.title("📈 Model Performance")
st.caption("Stage 3 Final Model Evaluation Results")

# Load metrics
metrics_path = settings.ARTIFACT_DIR / "stage3_final" / "metrics_hgb_full.json"
if not metrics_path.exists():
    metrics_path = settings.ARTIFACT_DIR / "metrics.json"

if not metrics_path.exists():
    st.error("Model metrics not found")
    st.stop()

with open(metrics_path) as f:
    metrics_data = json.load(f)

st.success(f"✅ Loaded metrics from: {metrics_path.name}")

# Model Info
st.subheader("Model Information")
col1, col2, col3, col4 = st.columns(4)
col1.metric("Selected Model", metrics_data.get('selected_model', 'N/A'))
col2.metric("Dataset", metrics_data.get('dataset', 'N/A'))
col3.metric("Selection Metric", metrics_data.get('selection_metric', 'N/A'))
col4.metric("Mode", metrics_data.get('mode', 'N/A'))

st.divider()

# Overall Performance
st.subheader("Overall Performance (Official Test Set - KDDTest+)")
test_metrics = metrics_data['test']['metrics']
col1, col2, col3, col4, col5 = st.columns(5)
col1.metric("Accuracy", f"{test_metrics['accuracy']:.4f}")
col2.metric("Balanced Accuracy", f"{test_metrics['balanced_accuracy']:.4f}")
col3.metric("Macro-F1", f"{test_metrics['macro_f1']:.4f}")
col4.metric("Weighted-F1", f"{test_metrics['weighted_f1']:.4f}")
col5.metric("Top-2 Accuracy", f"{test_metrics.get('top2_accuracy', 0):.4f}" if test_metrics.get('top2_accuracy') else "N/A")

st.divider()

# Attack Detection Performance
st.subheader("Binary Attack Detection (Benign vs Attack)")
binary = test_metrics['binary_attack']
col1, col2, col3, col4, col5 = st.columns(5)
col1.metric("Attack Precision", f"{binary['precision']:.4f}")
col2.metric("Attack Recall", f"{binary['recall']:.4f}")
col3.metric("Attack F1", f"{binary['f1']:.4f}")
col4.metric("False Positive Rate", f"{binary['false_positive_rate']:.4f}")
col5.metric("ROC-AUC", f"{binary['roc_auc']:.4f}" if binary['roc_auc'] else "N/A")

st.info(f"True Positives: {binary['true_positive']:,} | False Positives: {binary['false_positive']:,} | False Negatives: {binary['false_negative']:,} | True Negatives: {binary['true_negative']:,}")

st.divider()

# Per-Class Performance
st.subheader("Per-Class Performance")
per_class_df = pd.DataFrame.from_dict(test_metrics['per_class'], orient='index')
per_class_df = per_class_df.reset_index().rename(columns={'index': 'Class'})
per_class_df = per_class_df[['Class', 'precision', 'recall', 'f1', 'support']]
per_class_df = per_class_df.sort_values('support', ascending=False)
st.dataframe(per_class_df, use_container_width=True, hide_index=True)

# Per-class chart
fig = px.bar(per_class_df, x='Class', y=['precision', 'recall', 'f1'], 
             barmode='group', title='Precision, Recall, F1 by Class',
             labels={'value': 'Score', 'variable': 'Metric'})
fig.update_layout(height=400)
st.plotly_chart(fig, use_container_width=True)

st.divider()

# Confusion Matrix
st.subheader("Confusion Matrix (Official Test Set)")
cm_data = test_metrics['confusion_matrix']
labels = cm_data['labels']
matrix = cm_data['matrix']

fig = go.Figure(data=go.Heatmap(
    z=matrix,
    x=labels,
    y=labels,
    colorscale='Blues',
    text=matrix,
    texttemplate='%{text}',
    textfont={"size": 12},
))
fig.update_layout(
    title='Confusion Matrix',
    xaxis_title='Predicted',
    yaxis_title='Actual',
    height=500
)
st.plotly_chart(fig, use_container_width=True)

st.caption(f"Test samples: {test_metrics['n_samples']:,} | Evaluated exactly once on official KDDTest+")
