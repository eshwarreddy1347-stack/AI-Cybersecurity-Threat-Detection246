"""Load, validate and label NSL-KDD connection records.

The loader is deliberately strict about the dataset contract (43 columns,
known attack labels, numeric features) so upstream mistakes surface here
instead of silently corrupting a model later.

Public API
----------
read_connections(path)      read a raw NSL-KDD file or a headed CSV export
label_connections(df)       add attack_type / category / is_attack columns
load_split("train"|"test")  load an official split with row-count validation
load_dataset()              both official splits as a dict
profile(df)                 compact quality summary used by the EDA script
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import settings  # noqa: E402

FEATURE_COLUMNS: list[str] = settings.NSL_KDD_COLUMNS[:41]
# Numeric *features* only. "difficulty" is dataset metadata, not a signal.
NUMERIC_COLUMNS: list[str] = [
    column for column in FEATURE_COLUMNS if column not in settings.CATEGORICAL_FEATURES
]
# Columns that still need numeric coercion when reading a file.
COERCE_NUMERIC: list[str] = NUMERIC_COLUMNS + ["difficulty"]
REQUIRED_COLUMNS: list[str] = FEATURE_COLUMNS + ["label"]

_LABEL_MAP: dict[str, str] = {
    name.lower(): category for name, category in settings.ATTACK_CATEGORY_MAP.items()
}

# NSL-KDD "service" values occasionally carry a trailing underscore in
# derived copies (e.g. "domain_u"). Keep them distinct; only normalise case.
_CATEGORICAL_SET = set(settings.CATEGORICAL_FEATURES)


class DataValidationError(ValueError):
    """Raised when a file does not satisfy the NSL-KDD contract."""


def _has_header(path: Path) -> bool:
    """Detect a headed CSV export without reading the whole file."""
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        first_line = handle.readline()
    first_cell = first_line.split(",", 1)[0].strip().strip('"').lower()
    return first_cell in {"duration", *settings.NSL_KDD_COLUMNS}


def _normalise_labels(values: pd.Series) -> pd.Series:
    """Lower-case attack labels and drop the trailing period some mirrors add."""
    return values.astype("string").str.strip().str.rstrip(".").str.lower()


def _coerce_types(frame: pd.DataFrame) -> pd.DataFrame:
    """Strip whitespace, normalise labels and force numeric dtypes."""
    frame = frame.copy()
    for column in _CATEGORICAL_SET:
        frame[column] = frame[column].astype("string").str.strip()

    frame["label"] = _normalise_labels(frame["label"])

    for column in COERCE_NUMERIC:
        # Some NSL-KDD mirrors terminate the difficulty column with a period.
        frame[column] = pd.to_numeric(
            frame[column].astype("string").str.strip().str.rstrip("."),
            errors="coerce",
        )
    return frame


def read_connections(path: str | Path) -> pd.DataFrame:
    """Read an NSL-KDD file (headerless) or a headed CSV export."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"dataset file not found: {path}")
    if path.stat().st_size == 0:
        raise DataValidationError(f"dataset file is empty: {path}")

    common = {"sep": ",", "skipinitialspace": True}
    if _has_header(path):
        frame = pd.read_csv(path, header=0, **common)
        missing = [c for c in REQUIRED_COLUMNS if c not in frame.columns]
        if missing:
            raise DataValidationError(
                f"{path.name}: missing required columns: {', '.join(missing)}"
            )
        # Keep the canonical order; ignore any extra presentation columns.
        extra = [c for c in frame.columns if c not in settings.NSL_KDD_COLUMNS]
        if extra:
            frame = frame.drop(columns=extra)
        available = [c for c in settings.NSL_KDD_COLUMNS if c in frame.columns]
        frame = frame[available]
    else:
        frame = pd.read_csv(
            path, header=None, names=settings.NSL_KDD_COLUMNS, **common
        )

    if len(frame.columns) != len(settings.NSL_KDD_COLUMNS):
        raise DataValidationError(
            f"{path.name}: expected {len(settings.NSL_KDD_COLUMNS)} columns, "
            f"found {len(frame.columns)}"
        )

    frame = _coerce_types(frame)

    missing_values = frame[REQUIRED_COLUMNS].isna().sum()
    broken = missing_values[missing_values > 0]
    if not broken.empty:
        raise DataValidationError(
            f"{path.name}: missing or non-numeric values in "
            + ", ".join(f"{col} ({count})" for col, count in broken.items())
        )
    return frame


def label_connections(frame: pd.DataFrame) -> pd.DataFrame:
    """Add ``attack_type``, ``category`` and ``is_attack`` columns.

    Raises DataValidationError when an attack label is not in the configured
    mapping - a silent fallback to 'Normal' would hide dataset drift.
    """
    if "label" not in frame.columns:
        raise DataValidationError("frame has no 'label' column")

    labelled = frame.copy()
    raw_labels = _normalise_labels(labelled["label"])
    unknown = sorted(set(raw_labels.dropna()) - set(_LABEL_MAP))
    if unknown:
        preview = ", ".join(repr(name) for name in unknown[:10])
        suffix = "" if len(unknown) <= 10 else f" (+{len(unknown) - 10} more)"
        raise DataValidationError(
            f"unknown attack label(s): {preview}{suffix}. "
            "Add them to config.settings.ATTACK_CATEGORY_MAP."
        )

    labelled["attack_type"] = raw_labels
    labelled["category"] = raw_labels.map(_LABEL_MAP).astype("string")
    labelled["is_attack"] = labelled["category"] != "Normal"
    return labelled


def load_split(split: str, *, strict: bool = True) -> pd.DataFrame:
    """Load one official split and validate its shape and labels."""
    if split not in settings.DATASET_FILES:
        raise ValueError(f"unknown split {split!r}; expected 'train' or 'test'")

    path = settings.RAW_DIR / settings.DATASET_FILES[split]
    frame = label_connections(read_connections(path))

    if strict:
        expected_rows = settings.DATASET_EXPECTED_ROWS[split]
        if len(frame) != expected_rows:
            raise DataValidationError(
                f"{path.name}: expected {expected_rows:,} rows, "
                f"found {len(frame):,}. Re-download with --force."
            )
    return frame


def load_dataset(*, strict: bool = True) -> dict[str, pd.DataFrame]:
    """Load both official splits as ``{"train": df, "test": df}``."""
    settings.ensure_directories()
    return {
        split: load_split(split, strict=strict)
        for split in settings.DATASET_FILES
    }


def feature_hash(frame: pd.DataFrame) -> pd.Series:
    """Stable hash of the 41 feature values, used for duplicate analysis."""
    return pd.util.hash_pandas_object(frame[FEATURE_COLUMNS], index=False)


def profile(frame: pd.DataFrame) -> dict[str, object]:
    """Return a JSON-serialisable quality summary for one split."""
    numeric = frame[NUMERIC_COLUMNS]
    constant_columns = [
        column for column in NUMERIC_COLUMNS if numeric[column].nunique() <= 1
    ]
    hashes = feature_hash(frame)
    return {
        "rows": int(len(frame)),
        "columns": int(frame.shape[1]),
        "duplicate_feature_rows": int(hashes.duplicated().sum()),
        "missing_values": int(frame[REQUIRED_COLUMNS].isna().sum().sum()),
        "constant_numeric_columns": constant_columns,
        "class_counts": {
            str(key): int(value)
            for key, value in frame["category"].value_counts().items()
        },
        "attack_types": {
            str(key): int(value)
            for key, value in frame["attack_type"].value_counts().items()
        },
        "protocols": {
            str(key): int(value)
            for key, value in frame["protocol_type"].value_counts().items()
        },
        "feature_hashes": hashes,
    }
