"""Feature engineering for NSL-KDD.

Design rules
------------
1. The transformer is fitted on the **training split only**. Every later
   transform (test set, uploaded CSV, dashboard input) reuses the fitted
   object, so no test information leaks into scaling or one-hot categories.
2. Categorical fields use ``handle_unknown="ignore"`` because the official
   test set contains services and flags that never appear in training.
3. Heavy-tailed count/byte fields are log-transformed before scaling; NSL-KDD
   numeric features are all non-negative, which ``assert_non_negative``
   enforces so ``log1p`` can never silently produce NaN.
4. ``OneHotEncoder`` output is dense and the whole transformer emits a
   DataFrame, so feature names stay attached for the evidence panel later.
"""

from __future__ import annotations

import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import settings  # noqa: E402
from src.data.loader import FEATURE_COLUMNS, NUMERIC_COLUMNS  # noqa: E402

PREPROCESSOR_FILENAME = "preprocessor.joblib"


def assert_non_negative(frame: pd.DataFrame) -> None:
    """Guard the log1p transform: every numeric NSL-KDD feature is >= 0."""
    numeric = frame[NUMERIC_COLUMNS]
    minimum = numeric.min()
    offending = minimum[minimum < 0]
    if not offending.empty:
        detail = ", ".join(f"{col}={value}" for col, value in offending.items())
        raise ValueError(f"negative values found in numeric features: {detail}")


def build_preprocessor() -> ColumnTransformer:
    """Create an unfitted column transformer for the 41 raw features."""
    numeric_pipeline = Pipeline(
        steps=[
            (
                "log1p",
                FunctionTransformer(
                    np.log1p,
                    feature_names_out="one-to-one",
                    validate=False,
                ),
            ),
            ("scale", StandardScaler()),
        ]
    )

    categorical_pipeline = Pipeline(
        steps=[
            (
                "onehot",
                OneHotEncoder(
                    handle_unknown="ignore",
                    sparse_output=False,
                    dtype=np.float64,
                ),
            )
        ]
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, NUMERIC_COLUMNS),
            ("categorical", categorical_pipeline, settings.CATEGORICAL_FEATURES),
        ],
        remainder="drop",
        sparse_threshold=0.0,
        verbose_feature_names_out=True,
    )
    preprocessor.set_output(transform="pandas")
    return preprocessor


def build_xy(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series, pd.Series]:
    """Split a labelled frame into X, 5-class y and binary y (1 = attack)."""
    missing = [column for column in FEATURE_COLUMNS if column not in frame.columns]
    if missing:
        raise ValueError(f"frame is missing feature columns: {missing}")
    if "category" not in frame.columns:
        raise ValueError("frame must be labelled with label_connections() first")

    features = frame[FEATURE_COLUMNS].copy()
    multi_target = frame["category"].astype(str).copy()
    binary_target = (multi_target != "Normal").astype(int)
    return features, multi_target, binary_target


def transform_frame(preprocessor: ColumnTransformer, frame: pd.DataFrame) -> pd.DataFrame:
    """Transform raw feature rows with an already-fitted preprocessor."""
    assert_non_negative(frame)
    transformed = preprocessor.transform(frame[FEATURE_COLUMNS])
    if isinstance(transformed, np.ndarray):
        names = preprocessor.get_feature_names_out()
        transformed = pd.DataFrame(transformed, columns=names, index=frame.index)
    return transformed


def save_preprocessor(
    preprocessor: ColumnTransformer,
    path: Path | None = None,
) -> Path:
    """Persist the fitted transformer so the app never refits at runtime."""
    destination = path or (settings.ARTIFACT_DIR / PREPROCESSOR_FILENAME)
    destination.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(preprocessor, destination)
    return destination


def load_preprocessor(path: Path | None = None) -> ColumnTransformer:
    """Load the fitted transformer saved by ``scripts/prepare_features.py``."""
    source = path or (settings.ARTIFACT_DIR / PREPROCESSOR_FILENAME)
    if not source.is_file():
        raise FileNotFoundError(
            f"preprocessor artifact not found: {source}. "
            "Run: python scripts\\prepare_features.py"
        )
    return joblib.load(source)


def categorical_vocabularies(preprocessor: ColumnTransformer) -> dict[str, list[str]]:
    """Return the fitted one-hot categories, keyed by raw column name."""
    encoder: OneHotEncoder = preprocessor.named_transformers_["categorical"][
        "onehot"
    ]
    return {
        column: [str(value) for value in values]
        for column, values in zip(
            settings.CATEGORICAL_FEATURES, encoder.categories_, strict=True
        )
    }


def unseen_categories(
    preprocessor: ColumnTransformer, frame: pd.DataFrame
) -> dict[str, int]:
    """Count values per categorical column that the encoder has never seen."""
    vocabularies = categorical_vocabularies(preprocessor)
    unseen: dict[str, int] = {}
    for column, known in vocabularies.items():
        values = frame[column].astype(str)
        unseen[column] = int((~values.isin(known)).sum())
    return unseen
