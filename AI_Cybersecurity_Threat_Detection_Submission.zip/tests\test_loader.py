"""Tests for the Stage 1 dataset loader."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import pytest

from config import settings
from src.data.loader import (
    FEATURE_COLUMNS,
    DataValidationError,
    label_connections,
    load_dataset,
    read_connections,
)

SPLITS_PRESENT = all(
    (settings.RAW_DIR / filename).is_file()
    for filename in settings.DATASET_FILES.values()
)


def _row(label: str = "normal", *, service: str = "http") -> list[object]:
    """Build one syntactically valid NSL-KDD row."""
    row: list[object] = [0, "tcp", service, "SF"] + [0] * 37
    row += [label, 20]
    assert len(row) == 43
    return row


def _write(tmp_path: Path, rows: list[list[object]], header: bool = False) -> Path:
    path = tmp_path / "sample.csv"
    frame = pd.DataFrame(rows)
    if header:
        frame.columns = settings.NSL_KDD_COLUMNS
    frame.to_csv(path, index=False, header=header)
    return path


def test_reads_headerless_nsl_kdd_format(tmp_path):
    path = _write(tmp_path, [_row("normal"), _row("neptune")])
    frame = read_connections(path)
    assert list(frame.columns) == settings.NSL_KDD_COLUMNS
    assert len(frame) == 2
    assert frame["label"].tolist() == ["normal", "neptune"]
    assert frame["duration"].dtype.kind in "if"


def test_reads_headed_csv_and_ignores_extra_columns(tmp_path):
    path = tmp_path / "headed.csv"
    frame = pd.DataFrame([_row("neptune")], columns=settings.NSL_KDD_COLUMNS)
    frame["analyst_note"] = "demo"
    frame.to_csv(path, index=False)
    loaded = read_connections(path)
    assert "analyst_note" not in loaded.columns
    assert list(loaded.columns) == settings.NSL_KDD_COLUMNS
    assert loaded.loc[0, "label"] == "neptune"


def test_missing_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        read_connections(tmp_path / "nope.csv")


def test_short_row_is_rejected(tmp_path):
    path = tmp_path / "short.csv"
    path.write_text("0,tcp,http\n", encoding="utf-8")
    with pytest.raises(DataValidationError):
        read_connections(path)


def test_label_mapping():
    frame = pd.DataFrame(
        {
            "label": ["normal", "neptune", "satan", "guess_passwd", "buffer_overflow"],
        }
    )
    labelled = label_connections(frame)
    assert labelled["category"].tolist() == ["Normal", "DoS", "Probe", "R2L", "U2R"]
    assert labelled["is_attack"].tolist() == [False, True, True, True, True]


def test_unknown_label_is_rejected():
    frame = pd.DataFrame({"label": ["normal", "totally_new_attack"]})
    with pytest.raises(DataValidationError, match="totally_new_attack"):
        label_connections(frame)


def test_trailing_period_in_label_is_tolerated():
    frame = pd.DataFrame({"label": ["neptune."]})
    assert label_connections(frame).loc[0, "category"] == "DoS"


@pytest.mark.skipif(not SPLITS_PRESENT, reason="NSL-KDD files not downloaded")
def test_official_row_counts_and_classes():
    dataset = load_dataset()
    assert len(dataset["train"]) == settings.DATASET_EXPECTED_ROWS["train"]
    assert len(dataset["test"]) == settings.DATASET_EXPECTED_ROWS["test"]
    for frame in dataset.values():
        assert set(frame["category"]) == set(settings.CLASS_ORDER)
        assert frame[FEATURE_COLUMNS].isna().sum().sum() == 0
        assert pd.api.types.is_bool_dtype(frame["is_attack"])
