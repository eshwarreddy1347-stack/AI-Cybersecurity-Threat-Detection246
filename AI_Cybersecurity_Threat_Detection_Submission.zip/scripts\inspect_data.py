"""Inspect the NSL-KDD splits and produce a small demo sample.

Run:
    python scripts\\inspect_data.py

Writes:
    data/processed/eda_summary.json     machine-readable quality summary
    data/demo/demo_connections.csv      stratified sample for the demo feed
"""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import settings  # noqa: E402
from src.data.loader import (  # noqa: E402
    FEATURE_COLUMNS,
    load_dataset,
    profile,
)

DEMO_ROWS_PER_CLASS = 500
DEMO_FILENAME = "demo_connections.csv"


def _print_distribution(title: str, counts: dict[str, int], order: list[str] | None = None) -> None:
    total = sum(counts.values()) or 1
    keys = order or sorted(counts, key=counts.get, reverse=True)
    print(f"\n{title}")
    print(f"  {'class':<15}{'count':>9}{'share':>9}")
    print("  " + "-" * 33)
    for key in keys:
        count = counts.get(key, 0)
        print(f"  {key:<15}{count:>9,}{100 * count / total:>8.2f}%")
    print("  " + "-" * 33)
    print(f"  {'total':<15}{total:>9,}{100.0:>8.2f}%")


def _build_demo_sample(test_frame: pd.DataFrame) -> pd.DataFrame:
    """Stratified sample so every attack family appears in the demo."""
    parts = []
    for category in settings.CLASS_ORDER:
        subset = test_frame[test_frame["category"] == category]
        take = min(DEMO_ROWS_PER_CLASS, len(subset))
        if take:
            parts.append(subset.sample(n=take, random_state=settings.RANDOM_STATE))
    sample = pd.concat(parts).sample(
        frac=1, random_state=settings.RANDOM_STATE
    ).reset_index(drop=True)
    return sample[settings.NSL_KDD_COLUMNS]


def main() -> int:
    settings.ensure_directories()
    print(f"Dataset: {settings.DATASET_NAME}")
    print(f"Source : {settings.RAW_DIR}")

    splits = load_dataset()
    summaries: dict[str, dict[str, object]] = {}
    hashes: dict[str, pd.Series] = {}

    for name, frame in splits.items():
        info = profile(frame)
        hashes[name] = info.pop("feature_hashes")  # type: ignore[assignment]
        summaries[name] = info
        path = settings.RAW_DIR / settings.DATASET_FILES[name]
        print(
            f"\n[{name}] {path.name}: {info['rows']:,} rows x "
            f"{info['columns']} columns, {path.stat().st_size / 1e6:.1f} MB"
        )
        _print_distribution(
            f"[{name}] class distribution", info["class_counts"], settings.CLASS_ORDER
        )
        attacks = dict(
            sorted(info["attack_types"].items(), key=lambda kv: kv[1], reverse=True)
        )
        top = dict(list(attacks.items())[:12])
        print(f"\n[{name}] top attack types (of {len(attacks)} distinct labels)")
        for label, count in top.items():
            print(f"  {label:<18}{count:>8,}")
        if len(attacks) > len(top):
            print(f"  ... {len(attacks) - len(top)} more labels")

        print(f"\n[{name}] quality checks")
        print(f"  duplicate feature rows : {info['duplicate_feature_rows']:,}")
        print(f"  missing values         : {info['missing_values']}")
        print(
            "  constant columns       : "
            + (", ".join(info["constant_numeric_columns"]) or "none")
        )
        print(f"  protocols              : {info['protocols']}")

    overlap = len(set(hashes["train"]) & set(hashes["test"]))
    print("\nTrain/test overlap")
    print(f"  identical feature rows in both splits: {overlap:,}")
    print(
        "  note: NSL-KDD intentionally keeps a small number of overlapping\n"
        "        flows; models are evaluated on the official test split, so\n"
        "        the reported score is still an unseen-attack estimate."
    )

    demo = _build_demo_sample(splits["test"])
    demo_path = settings.DEMO_DIR / DEMO_FILENAME
    demo.to_csv(demo_path, index=False)
    print(f"\nDemo sample: {len(demo):,} rows -> {demo_path}")

    summary_path = settings.PROCESSED_DIR / "eda_summary.json"
    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "dataset": settings.DATASET_NAME,
        "train_test_overlap_rows": overlap,
        "demo_sample_rows": int(len(demo)),
        "splits": summaries,
    }
    summary_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"EDA summary -> {summary_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
