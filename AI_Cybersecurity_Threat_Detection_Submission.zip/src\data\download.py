"""Download the public NSL-KDD dataset into ``data/raw``.

The files are fetched once and cached. Re-running is safe: existing files are
skipped unless ``--force`` is passed. Downloads are written to a temporary
``.part`` file and renamed only after completion, so an interrupted download
never leaves a corrupt dataset behind.

Usage:
    python src\\data\\download.py
    python src\\data\\download.py --force
"""

from __future__ import annotations

import argparse
import sys
import urllib.error
import urllib.request
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import settings  # noqa: E402

CHUNK_SIZE = 1 << 16  # 64 KiB
USER_AGENT = "nsl-kdd-coursework/1.0 (offline academic project)"


def _format_bytes(num: int) -> str:
    value = float(num)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:,.1f} {unit}"
        value /= 1024
    return f"{value:,.1f} GB"


def download_file(url: str, destination: Path, force: bool = False) -> Path:
    """Download ``url`` to ``destination``. Returns the final path."""
    if destination.exists() and not force:
        print(
            f"[skip] {destination.name} already present "
            f"({_format_bytes(destination.stat().st_size)})"
        )
        return destination

    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + ".part")

    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    print(f"[get ] {destination.name} <- {url}")
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            total = int(response.headers.get("Content-Length") or 0)
            received = 0
            last_bucket = -1
            with temporary.open("wb") as handle:
                while True:
                    chunk = response.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    handle.write(chunk)
                    received += len(chunk)
                    if total:
                        bucket = int(10 * received / total)
                        if bucket != last_bucket:
                            last_bucket = bucket
                            print(
                                f"       {min(bucket * 10, 100):3d}%  "
                                f"{_format_bytes(received)} / {_format_bytes(total)}"
                            )
                    elif received // (5 * 1024 * 1024) != last_bucket:
                        last_bucket = received // (5 * 1024 * 1024)
                        print(f"       {_format_bytes(received)}")
        print()
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        temporary.unlink(missing_ok=True)
        raise SystemExit(
            f"[fail] could not download {url}\n       {exc}\n"
            "       If you are offline, place the file manually in "
            f"{destination.parent} and re-run."
        ) from exc

    if temporary.stat().st_size == 0:
        temporary.unlink(missing_ok=True)
        raise SystemExit(f"[fail] downloaded file is empty: {url}")

    temporary.replace(destination)
    print(f"[ok  ] saved {destination} ({_format_bytes(destination.stat().st_size)})")
    return destination


def download_dataset(force: bool = False) -> dict[str, Path]:
    """Download every configured dataset split. Returns split -> path."""
    settings.ensure_directories()
    paths: dict[str, Path] = {}
    for split, filename in settings.DATASET_FILES.items():
        url = settings.DATASET_URLS[split]
        paths[split] = download_file(url, settings.RAW_DIR / filename, force=force)
    return paths


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument(
        "--force",
        action="store_true",
        help="re-download even if the files already exist",
    )
    args = parser.parse_args(argv)

    download_dataset(force=args.force)
    print("\nDataset ready in", settings.RAW_DIR)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
