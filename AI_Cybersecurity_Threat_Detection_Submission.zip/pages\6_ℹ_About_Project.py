"""About Project - Project information and methodology"""

import streamlit as st
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from config import settings

st.set_page_config(page_title="About Project", page_icon="ℹ️", layout="wide")

st.title("ℹ️ About Project")
st.caption("AI-Based Cybersecurity Threat Detection and Analysis")

st.divider()

# Project Info
st.subheader("Project Overview")
st.markdown("""
**Title:** AI-Based Cybersecurity Threat Detection and Analysis

**Objective:** Apply supervised machine learning to detect and analyze network intrusions using the public NSL-KDD dataset, presented in a professional Streamlit dashboard with alert management capabilities.

**Technology Stack:**
- **Language:** Python 3.11+
- **Machine Learning:** scikit-learn (HistGradientBoosting)
- **Dashboard:** Streamlit
- **Database:** SQLite
- **Data Processing:** pandas, numpy
- **Visualization:** Plotly
""")

st.divider()

# Dataset
st.subheader("Dataset")
st.markdown("""
**NSL-KDD** (Public dataset from University of New Brunswick)

- **Training Set:** 125,973 records
- **Test Set:** 22,544 records
- **Features:** 41 features + label + difficulty score
- **Attack Classes:** Normal, DoS, Probe, R2L, U2R
- **Note:** Dataset contains no IP addresses - asset information in the dashboard is simulated presentation metadata
""")

st.divider()

# Methodology
st.subheader("Methodology")

col1, col2 = st.columns(2)

with col1:
    st.markdown("""
    **Data Preprocessing:**
    1. Load and validate NSL-KDD format
    2. Map attack labels to categories (Normal, DoS, Probe, R2L, U2R)
    3. Feature engineering: log1p transformation for numeric features
    4. Standard scaling for numeric features
    5. One-hot encoding for categorical features (protocol_type, service, flag)
    6. Fitted on training data only (no data leakage)
    """)

with col2:
    st.markdown("""
    **Model Training:**
    1. Stratified train/validation split
    2. Compare Logistic Regression, Random Forest, HistGradientBoosting
    3. Select best model by macro-F1
    4. Final evaluation on official test set (used once)
    5. Transparent risk scoring with configurable weights
    """)

st.divider()

# Risk Model
st.subheader("Risk Scoring Model")
st.markdown(f"""
**Formula:**
```
risk = 0.4 × (100 × confidence) + 0.6 × severity_weight + capped modifiers
```

**Severity Weights:** {settings.SEVERITY_WEIGHTS}

**Severity Bands:**
- Critical: ≥ 85
- High: ≥ 70
- Medium: ≥ 40
- Low: < 40

**Modifiers (capped at {settings.RISK_MODIFIER_CAP}):** {settings.RISK_MODIFIERS}

**Thresholds:**
- Alert Confidence Threshold: {settings.ALERT_CONFIDENCE_THRESHOLD}
- Risk Alert Threshold: {settings.RISK_ALERT_THRESHOLD}
""")

st.divider()

# Safety & Scope
st.subheader("Safety & Scope")
st.warning("""
**Important Safety Notice:**
- This is an **offline analysis tool only**
- **No live network traffic capture**
- **No automatic blocking, isolation, or modification**
- **No connection to network devices**
- Alerts are read-and-annotate records only
- Asset names are **simulated presentation metadata** (NSL-KDD has no IP addresses)
""")

st.divider()

# Project Status
st.subheader("Development Stages")
status_data = {
    "Stage": ["0: Scaffold", "1: Dataset & EDA", "2: Feature Pipeline", "3: Model Training & Evaluation", "4: Risk Scoring & Alerts", "5: Streamlit Dashboard"],
    "Status": ["✅ Complete", "✅ Complete", "✅ Complete", "✅ Complete", "✅ Complete", "✅ Complete"]
}
st.table(pd.DataFrame(status_data))

st.divider()
st.caption("B.Tech Project - AI-Based Cybersecurity Threat Detection and Analysis")
