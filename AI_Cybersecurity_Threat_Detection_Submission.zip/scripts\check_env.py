"""Environment health check.

Usage:
    .venv\\Scripts\\python.exe scripts\\check_env.py

Prints a pass/fail table for the interpreter, dependencies, folders and
configuration, then exits with status 0 (healthy) or 1 (problem found).
"""

from __future__ import annotations

import importlib.metadata as metadata
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

REQUIRED_PACKAGES = [
    "streamlit",
    "pandas",
    "numpy",
    "scikit-learn",
    "joblib",
    "plotly",
    "pyarrow",
    "pytest",
]

MIN_PYTHON = (3, 11)


def _status(ok: bool) -> str:
    return "OK" if ok else "FAIL"


def main() -> int:
    failures = 0
    rows: list[tuple[str, str, str]] = []

    py_ok = sys.version_info >= MIN_PYTHON
    failures += 0 if py_ok else 1
    rows.append(
        (
            "Python",
            f"{sys.version.split()[0]} ({sys.executable})",
            _status(py_ok),
        )
    )

    for package in REQUIRED_PACKAGES:
        try:
            version = metadata.version(package)
            rows.append((package, version, "OK"))
        except metadata.PackageNotFoundError:
            rows.append((package, "not installed", "FAIL"))
            failures += 1

    try:
        from config import settings

        rows.append(("config", "imported", "OK"))
    except Exception as exc:  # pragma: no cover - defensive
        rows.append(("config", f"import failed: {exc}", "FAIL"))
        failures += 1
        settings = None  # type: ignore[assignment]

    if settings is not None:
        settings.ensure_directories()
        folders = [
            settings.RAW_DIR,
            settings.PROCESSED_DIR,
            settings.DEMO_DIR,
            settings.ARTIFACT_DIR,
        ]
        missing = [str(p) for p in folders if not p.is_dir()]
        rows.append(
            (
                "folders",
                "data/processed, data/demo, artifacts ready"
                if not missing
                else f"missing: {', '.join(missing)}",
                _status(not missing),
            )
        )
        failures += 0 if not missing else 1

        config_ok = (
            set(settings.CLASS_ORDER) == set(settings.SEVERITY_WEIGHTS)
            and len(settings.NSL_KDD_COLUMNS) == 43
            and set(settings.ATTACK_CATEGORY_MAP.values())
            <= set(settings.CLASS_ORDER)
        )
        rows.append(
            (
                "config sanity",
                f"{len(settings.CLASS_ORDER)} classes, "
                f"{len(settings.ATTACK_CATEGORY_MAP)} label mappings",
                _status(config_ok),
            )
        )
        failures += 0 if config_ok else 1

    name_width = max(len(r[0]) for r in rows) + 2
    print()
    print("AI-Based Cybersecurity Threat Detection - environment check")
    print("=" * 78)
    for name, detail, status in rows:
        print(f"{name:<{name_width}} {status:<5} {detail}")
    print("=" * 78)

    if failures:
        print(f"RESULT: {failures} problem(s) found.")
        return 1
    print("RESULT: environment OK.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
