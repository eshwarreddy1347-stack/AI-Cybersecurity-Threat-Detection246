"""Fit the feature pipeline on the training split and save it.

Run:
    python scripts\\prepare_features.py

Writes:
    artifacts/preprocessor.joblib      fitted ColumnTransformer
    artifacts/preprocessor_meta.json   shape, vocabularies, unseen categories
"""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import settings  # noqa: E402
from src.data.loader import load_dataset  # noqa: E402
from src.features.preprocess import (  # noqa: E402
    assert_non_negative,
    build_preprocessor,
    build_xy,
    categorical_vocabularies,
    save_preprocessor,
    transform_frame,
    unseen_categories,
)


def main() -> int:
    settings.ensure_directories()
    dataset = load_dataset()
    train, test = dataset["train"], dataset["test"]

    assert_non_negative(train)
    assert_non_negative(test)

    x_train, y_train_multi, y_train_bin = build_xy(train)
    x_test, y_test_multi, y_test_bin = build_xy(test)

    preprocessor = build_preprocessor()
    preprocessor.fit(x_train)

    train_matrix = transform_frame(preprocessor, x_train)
    test_matrix = transform_frame(preprocessor, x_test)

    vocab = categorical_vocabularies(preprocessor)
    unseen = unseen_categories(preprocessor, x_test)
    numeric_names = list(
        preprocessor.named_transformers_["numeric"].get_feature_names_out()
    )
    onehot_names = [
        name
        for name in train_matrix.columns
        if name.startswith("categorical__")
    ]

    print("Feature pipeline fitted on training split only")
    print(f"  raw features        : {x_train.shape[1]}")
    print(f"  encoded features    : {train_matrix.shape[1]}")
    print(f"  numeric block       : {len(numeric_names)} (log1p + standard scale)")
    print(f"  one-hot block       : {len(onehot_names)}")
    for column, values in vocab.items():
        print(f"    {column:<15} {len(values):>3} known values")
    print()
    print(f"  train matrix        : {train_matrix.shape}")
    print(f"  test matrix         : {test_matrix.shape}")
    print(f"  train attack rate   : {y_train_bin.mean():.3f}")
    print(f"  test attack rate    : {y_test_bin.mean():.3f}")
    print(f"  NaN in train matrix : {int(train_matrix.isna().sum().sum())}")
    print(f"  NaN in test matrix  : {int(test_matrix.isna().sum().sum())}")
    print()
    print("Unseen categorical values in the official test split")
    for column, count in unseen.items():
        print(f"  {column:<15} {count:>6,} rows (handled by one-hot ignore)")
    print()

    artifact = save_preprocessor(preprocessor)
    meta = {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "n_raw_features": int(x_train.shape[1]),
        "n_encoded_features": int(train_matrix.shape[1]),
        "n_train_rows": int(len(x_train)),
        "n_test_rows": int(len(x_test)),
        "train_attack_rate": round(float(y_train_bin.mean()), 4),
        "test_attack_rate": round(float(y_test_bin.mean()), 4),
        "numeric_columns": len(numeric_names),
        "onehot_columns": len(onehot_names),
        "vocabularies": {column: len(values) for column, values in vocab.items()},
        "unseen_test_values": unseen,
        "log_transform": "log1p",
        "scaler": "StandardScaler",
    }
    meta_path = settings.ARTIFACT_DIR / "preprocessor_meta.json"
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    print(f"Saved preprocessor -> {artifact}")
    print(f"Saved metadata     -> {meta_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
