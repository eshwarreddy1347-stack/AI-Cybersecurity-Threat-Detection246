"""Evaluation helpers for the five-class NSL-KDD task.

The dashboard, the report and the viva all quote the same numbers, so metrics
are computed in exactly one place and stored as JSON. Nothing here trains a
model; it only scores predictions.

Why these metrics
-----------------
NSL-KDD is heavily imbalanced (U2R is ~0.04% of the training split), so plain
accuracy hides failure on rare attacks. The primary metric is therefore
**macro-F1**, supported by per-class recall and a binary attack/benign view.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    precision_recall_fscore_support,
    roc_auc_score,
    top_k_accuracy_score,
)

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import settings  # noqa: E402


def _binary_attack_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_proba: np.ndarray | None,
    model_classes: list[str],
) -> dict[str, Any]:
    """Score the detection task as benign (0) vs attack (1)."""
    true_binary = (y_true != "Normal").astype(int)
    pred_binary = (y_pred != "Normal").astype(int)
    matrix = confusion_matrix(true_binary, pred_binary, labels=[0, 1])
    tn, fp, fn, tp = (int(value) for value in matrix.ravel())

    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = (
        2 * precision * recall / (precision + recall)
        if (precision + recall)
        else 0.0
    )
    false_positive_rate = fp / (fp + tn) if (fp + tn) else 0.0

    roc_auc: float | None = None
    if (
        y_proba is not None
        and "Normal" in model_classes
        and len(set(true_binary.tolist())) == 2
    ):
        normal_index = model_classes.index("Normal")
        attack_score = 1.0 - y_proba[:, normal_index]
        roc_auc = float(roc_auc_score(true_binary, attack_score))

    return {
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "false_positive_rate": float(false_positive_rate),
        "roc_auc": roc_auc,
        "true_negative": tn,
        "false_positive": fp,
        "false_negative": fn,
        "true_positive": tp,
    }


def evaluate_model(
    estimator: Any,
    x: Any,
    y_true: Any,
    *,
    labels: list[str] | None = None,
) -> dict[str, Any]:
    """Score a fitted estimator and return a JSON-serialisable report.

    ``labels`` defaults to the union of observed and predicted classes. Pass
    ``settings.CLASS_ORDER`` when you want absent classes reported as zero
    instead of being silently dropped.
    """
    truth = np.asarray(y_true, dtype=str)
    predicted = np.asarray(estimator.predict(x), dtype=str)
    model_classes = [str(value) for value in getattr(estimator, "classes_", [])]

    report_labels = (
        list(labels)
        if labels is not None
        else sorted(set(truth.tolist()) | set(predicted.tolist()))
    )

    precision, recall, f1, support = precision_recall_fscore_support(
        truth,
        predicted,
        labels=report_labels,
        zero_division=0,
    )
    matrix = confusion_matrix(truth, predicted, labels=report_labels)

    y_proba: np.ndarray | None = None
    if hasattr(estimator, "predict_proba"):
        y_proba = np.asarray(estimator.predict_proba(x), dtype=float)

    top2: float | None = None
    if (
        y_proba is not None
        and len(model_classes) > 1
        and set(truth.tolist()) <= set(model_classes)
    ):
        try:
            top2 = float(
                top_k_accuracy_score(
                    truth,
                    y_proba,
                    k=2,
                    labels=model_classes,
                )
            )
        except ValueError:
            top2 = None

    per_class = {
        label: {
            "precision": float(precision[index]),
            "recall": float(recall[index]),
            "f1": float(f1[index]),
            "support": int(support[index]),
        }
        for index, label in enumerate(report_labels)
    }

    return {
        "n_samples": int(len(truth)),
        "accuracy": float(accuracy_score(truth, predicted)),
        "balanced_accuracy": float(balanced_accuracy_score(truth, predicted)),
        "macro_f1": float(
            f1_score(
                truth,
                predicted,
                labels=report_labels,
                average="macro",
                zero_division=0,
            )
        ),
        "weighted_f1": float(
            f1_score(
                truth,
                predicted,
                labels=report_labels,
                average="weighted",
                zero_division=0,
            )
        ),
        "top2_accuracy": top2,
        "per_class": per_class,
        "confusion_matrix": {
            "labels": report_labels,
            "matrix": matrix.astype(int).tolist(),
        },
        "binary_attack": _binary_attack_metrics(
            truth, predicted, y_proba, model_classes
        ),
    }


def format_metrics(
    metrics: dict[str, Any],
    *,
    title: str | None = None,
    detailed: bool = True,
) -> str:
    """Render a metrics dict as a compact console table."""
    lines: list[str] = []
    if title:
        lines.append(title)
    lines.append(
        f"  samples={metrics['n_samples']:,}  "
        f"accuracy={metrics['accuracy']:.4f}  "
        f"balanced-acc={metrics['balanced_accuracy']:.4f}  "
        f"macro-F1={metrics['macro_f1']:.4f}"
    )

    if not detailed:
        binary = metrics["binary_attack"]
        lines.append(
            f"  attack recall={binary['recall']:.4f}  "
            f"attack precision={binary['precision']:.4f}  "
            f"FPR={binary['false_positive_rate']:.4f}"
        )
        return "\n".join(lines)

    lines.append(
        f"  {'class':<8}{'precision':>11}{'recall':>9}{'f1':>9}{'support':>10}"
    )
    for label, row in metrics["per_class"].items():
        lines.append(
            f"  {label:<8}{row['precision']:>11.4f}{row['recall']:>9.4f}"
            f"{row['f1']:>9.4f}{row['support']:>10,}"
        )

    binary = metrics["binary_attack"]
    auc = binary["roc_auc"]
    auc_text = f"{auc:.4f}" if auc is not None else "n/a"
    lines.append(
        f"  attack: precision={binary['precision']:.4f}  "
        f"recall={binary['recall']:.4f}  f1={binary['f1']:.4f}  "
        f"FPR={binary['false_positive_rate']:.4f}  ROC-AUC={auc_text}"
    )
    return "\n".join(lines)
