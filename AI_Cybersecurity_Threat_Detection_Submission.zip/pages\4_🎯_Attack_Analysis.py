"""Attack Analysis - Analyze attack patterns and trends"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from src.alerts.db import AlertDB

st.set_page_config(page_title="Attack Analysis", page_icon="🎯", layout="wide")

st.title("🎯 Attack Analysis")
st.caption("Analyze attack patterns, trends, and distributions")

db = AlertDB()
alerts = db.get_all_alerts(limit=10000)

if not alerts:
    st.warning("No alerts in database")
    st.stop()

df = pd.DataFrame(alerts)
df['created_at'] = pd.to_datetime(df['created_at'])

attacks_df = df[df['predicted_class'] != 'Normal']

st.subheader("Attack Statistics")
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Attacks", len(attacks_df))
col2.metric("Unique Attack Types", attacks_df['predicted_class'].nunique())
col3.metric("Avg Confidence", f"{attacks_df['confidence'].mean():.4f}")
col4.metric("Avg Risk Score", f"{attacks_df['risk_score'].mean():.1f}")

st.divider()

col1, col2 = st.columns(2)

with col1:
    st.subheader("Attacks by Type")
    type_counts = attacks_df['predicted_class'].value_counts()
    fig = px.bar(x=type_counts.index, y=type_counts.values,
                 labels={'x': 'Attack Type', 'y': 'Count'},
                 color=type_counts.values, color_continuous_scale='Reds')
    fig.update_layout(height=400)
    st.plotly_chart(fig, use_container_width=True)

with col2:
    st.subheader("Attack Severity Distribution")
    sev_by_type = attacks_df.groupby(['predicted_class', 'severity']).size().reset_index(name='count')
    fig = px.sunburst(sev_by_type, path=['predicted_class', 'severity'], values='count',
                      color='severity', color_discrete_map={'Critical': '#d62728', 'High': '#ff7f0e', 'Medium': '#ffbb78', 'Low': '#98df8a'})
    fig.update_layout(height=400)
    st.plotly_chart(fig, use_container_width=True)

st.divider()

# Risk Score Analysis
st.subheader("Risk Score Distribution by Attack Type")
fig = px.box(attacks_df, x='predicted_class', y='risk_score', color='predicted_class',
             labels={'predicted_class': 'Attack Type', 'risk_score': 'Risk Score'})
fig.update_layout(height=400)
st.plotly_chart(fig, use_container_width=True)

st.divider()

# Temporal Analysis
st.subheader("Attack Trends Over Time")
attacks_df['hour'] = attacks_df['created_at'].dt.hour
hourly = attacks_df.groupby(['hour', 'predicted_class']).size().reset_index(name='count')
fig = px.line(hourly, x='hour', y='count', color='predicted_class', markers=True,
              labels={'hour': 'Hour of Day', 'count': 'Number of Attacks'})
fig.update_layout(height=400)
st.plotly_chart(fig, use_container_width=True)

st.divider()

# Top Targeted Assets (Simulated)
st.subheader("Top Targeted Assets (Simulated)")
st.caption("⚠️ Asset information is simulated presentation metadata")
asset_counts = attacks_df['asset'].value_counts().head(10)
fig = px.bar(x=asset_counts.index, y=asset_counts.values,
             labels={'x': 'Asset (Simulated)', 'y': 'Attack Count'},
             color=asset_counts.values, color_continuous_scale='Blues')
fig.update_layout(height=350)
st.plotly_chart(fig, use_container_width=True)
